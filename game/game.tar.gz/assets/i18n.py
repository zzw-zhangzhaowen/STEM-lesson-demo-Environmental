# -*- coding: utf-8 -*-
"""遊戲內三語文案表。

三個語言：
    hk = 粵語（繁體中文，香港用詞）—— 預設
    cn = 普通話（簡體中文，內地用詞）
    en = English

用法：
    from i18n import T, set_lang, item_name, bin_name
    T("menu.title")                 → 依目前語言回傳字串
    T("menu.level", n=1, title=..)  → 帶參數，用 str.format

設計說明：物品與垃圾桶的「內部識別碼」保持中文原名不變（例如 "飲品膠樽"），
只在畫面上顯示時才經過 item_name() 翻譯。這樣計分、規則、順序等邏輯完全
不受語言影響，改動風險最低。
"""

LANGS = ("hk", "cn", "en")
LANG = "hk"

# 表格：key -> (粵語繁中, 普通話簡中, English)
STRINGS = {
    # ---------- 通用按鈕 ----------
    "btn.back_levels": ("返回選關", "返回选关", "Back to levels"),
    "btn.back": ("選關", "选关", "Levels"),
    "btn.back_special": ("返回", "返回", "Back"),
    "btn.retry": ("重玩本關", "重玩本关", "Replay"),
    "btn.next": ("下一關", "下一关", "Next level"),
    "btn.mute": ("靜音", "静音", "Mute"),
    "btn.unmute": ("開啟聲音", "开启声音", "Sound on"),
    "btn.mute_short": ("開聲", "开声", "Unmute"),
    "btn.pause": ("暫停", "暂停", "Pause"),
    "btn.resume": ("繼續", "继续", "Resume"),
    "btn.check_work": ("我改好了 ✓", "我改好了 ✓", "I've fixed it ✓"),

    # ---------- 垃圾桶 ----------
    "bin.paper": ("廢紙", "废纸", "Paper"),
    "bin.plastic": ("膠樽／塑料", "塑料瓶／塑料", "Plastic"),
    "bin.metal": ("金屬", "金属", "Metal"),
    "bin.general": ("一般垃圾", "一般垃圾", "General waste"),
    "bin.paper.sym": ("紙", "纸", "P"),
    "bin.plastic.sym": ("膠", "胶", "B"),
    "bin.metal.sym": ("金", "金", "M"),
    "bin.general.sym": ("餘", "余", "T"),

    # ---------- 物品 ----------
    "item.drink": ("飲品膠樽", "饮料瓶", "Drink bottle"),
    "item.shampoo": ("洗頭水樽", "洗发水瓶", "Shampoo bottle"),
    "item.newspaper": ("報紙", "报纸", "Newspaper"),
    "item.box": ("乾淨紙箱", "干净纸箱", "Cardboard box"),
    "item.book": ("乾淨書本", "干净书本", "Book"),
    "item.can": ("鋁罐", "铝罐", "Aluminium can"),
    "item.tincan": ("罐頭盒", "罐头盒", "Tin can"),
    "item.tissue": ("用過的紙巾", "用过的纸巾", "Used tissue"),

    # ---------- 關卡名稱 ----------
    "lv.0": ("膠樽入門", "塑料瓶入门", "Bottles 101"),
    "lv.1": ("分類練習", "分类练习", "Sorting practice"),
    "lv.2": ("傳送帶挑戰", "传送带挑战", "Conveyor challenge"),
    "lv.3": ("除錯大挑戰", "调试大挑战", "Debug challenge"),
    "lv.4": ("分類小救援", "分类小救援", "Sorting rescue"),
    "lv.card.3": ("修好 1 條", "修好 1 条", "Fix 1 rule"),
    "lv.card.4": ("修好 2 條", "修好 2 条", "Fix 2 rules"),
    "lv.menu.2": ("四桶挑戰", "四桶挑战", "Four bins"),
    "lv.menu.3": ("積木除錯", "积木调试", "Block debug"),

    # ---------- 主選單 ----------
    "menu.title": ("地球媽媽拯救大作戰", "地球妈妈拯救大作战", "Save Mother Earth"),
    "menu.sub_game": ("香港垃圾分類與計算思維遊戲", "香港垃圾分类与计算思维游戏",
                      "A Hong Kong waste-sorting & thinking game"),
    "menu.sub_stem": ("香港小四至小五｜垃圾分類與計算思維", "香港小四至小五｜垃圾分类与计算思维",
                      "P4–P5 Hong Kong · Waste sorting & computational thinking"),
    "menu.sub_adventure": ("分類探險　×　計算思維", "分类探险　×　计算思维",
                           "Sorting adventure × Computational thinking"),
    "menu.locked_suffix": ("（未解鎖）", "（未解锁）", " (locked)"),
    "menu.level": ("第 {n} 關　{title}", "第 {n} 关　{title}", "Level {n} · {title}"),
    "menu.hint_pick": ("小四至小五　｜　選擇已解鎖的關卡開始", "小四至小五　｜　选择已解锁的关卡开始",
                       "P4–P5 · Pick an unlocked level to start"),
    "menu.hint_keys": ("滑鼠拖動物品或積木　·　Esc 返回選關　·　R 重玩",
                       "鼠标拖动物品或积木　·　Esc 返回选关　·　R 重玩",
                       "Drag items or blocks · Esc: levels · R: replay"),
    "menu.hint_drag": ("用滑鼠拖動物品　·　Esc 返回選關", "用鼠标拖动物品　·　Esc 返回选关",
                       "Drag items with the mouse · Esc: levels"),
    "menu.ai_entry": ("AI 學伴 · 課前任務", "AI 学伴 · 课前任务", "AI buddy · Pre-lesson task"),
    "menu.start": ("開始", "开始", "Start"),
    "menu.locked": ("未解鎖", "未解锁", "Locked"),
    "menu.try": ("試玩", "试玩", "Try"),
    "menu.best": ("最高 {n} 分", "最高 {n} 分", "Best {n}"),
    "menu.quiz": ("課後小測", "课后小测", "Quiz"),
    "menu.practice": ("練習模式", "练习模式", "Practice"),
    "menu.practice_hint": ("免 PIN", "免 PIN", "No PIN"),
    "menu.teacher": ("教師模式", "教师模式", "Teacher"),
    "menu.teacher_hint": ("需 PIN 登入", "需 PIN 登录", "PIN required"),
    "menu.pick_level": ("選一關開始。放錯桶時，小芽會給你一個提示。",
                        "选一关开始。放错桶时，小芽会给你一个提示。",
                        "Pick a level. If you sort wrongly, Sprout gives you a hint."),

    # ---------- 狀態列 ----------
    "hud.hp": ("生命值", "生命值", "Lives"),
    "hud.sorted": ("已分類 {c}／5", "已分类 {c}／5", "Sorted {c}/5"),
    "hud.combo": ("連擊 ×{c}", "连击 ×{c}", "Combo ×{c}"),
    "hud.score": ("分數 {s}", "分数 {s}", "Score {s}"),
    "hud.practice": ("練習中", "练习中", "Practice"),
    "hud.try_with_me": ("跟我試一試", "跟我试一试", "Try with me"),
    "hud.try_slow": ("慢慢試", "慢慢试", "Take your time"),

    # ---------- 目標 ----------
    "goal.label": ("目標：{goal}", "目标：{goal}", "Goal: {goal}"),
    "goal.0": ("放對 1 件", "放对 1 件", "Sort 1 item correctly"),
    "goal.1": ("放對 5 件", "放对 5 件", "Sort 5 items correctly"),
    "goal.2": ("取得 150 分，並保留至少 1 點生命值", "取得 150 分，并保留至少 1 点生命值",
               "Score 150 and keep at least 1 life"),
    "goal.2_short": ("150 分　·　至少保留 1 點生命", "150 分　·　至少保留 1 点生命",
                     "150 points · keep at least 1 life"),
    "hint.keys_play": ("Esc 返回選關　·　R 重玩本關", "Esc 返回选关　·　R 重玩本关",
                       "Esc: levels · R: replay"),

    # ---------- 遊戲內提示訊息 ----------
    "msg.inspect_rule": ("觀察錯誤規則，再拖動下方積木替換它。",
                         "观察错误规则，再拖动下方积木替换它。",
                         "Look at the wrong rule, then drag a block below to replace it."),
    "msg.lv0_intro": ("試一試：把膠樽拖進黃色的膠樽桶。", "试一试：把塑料瓶拖进黄色的桶。",
                      "Try it: drag the bottle into the yellow bin."),
    "msg.drag_how": ("按住物品，拖到合適的桶，再放開滑鼠。", "按住物品，拖到合适的桶，再放开鼠标。",
                     "Hold the item, drag it to the right bin, then release."),
    "msg.not_in_bin": ("請把物品放進桶內。", "请把物品放进桶内。", "Please drop the item into a bin."),
    "msg.correct": ("分類正確！", "分类正确！", "Correct!"),
    "msg.wait_next": ("　下一件 {s} 秒後到。", "　下一件 {s} 秒后到。", " Next item in {s} s."),
    "hud.beat": ("傳送帶每 {s} 秒送一件・分類好也要等下一件",
                 "传送带每 {s} 秒送一件・分类好也要等下一件",
                 "One item every {s} s — the next arrives on time even if you finish early"),
    "hud.answer_next": ("每件 {s} 秒・分類後立即換下一件",
                        "每件 {s} 秒・分类后立即换下一件",
                        "Up to {s} s per item. Sort it to get the next one."),
    "msg.next_tip": ("差一點！看看小芽的提示，再分類下一件。",
                     "差一点！看看小芽的提示，再分类下一件。",
                     "Read Sprout's hint, then sort the next item."),
    "msg.combo": ("連擊 ×{c}！額外加 5 分。", "连击 ×{c}！额外加 5 分。", "Combo ×{c}! +5 bonus."),
    "msg.wrong": ("再想一想：{item}應放進{bin}桶。", "再想一想：{item}应放进{bin}桶。",
                  "Think again: {item} goes in the {bin} bin."),
    "msg.rule_bad": ("程式仍把膠樽送到{bin}桶。請再換一塊積木。",
                     "程序仍把塑料瓶送到{bin}桶。请再换一块积木。",
                     "The program still sends the bottle to {bin}. Try another block."),
    "msg.rule_ok": ("規則已更換。請預測程式會把每件物品送到哪個桶。",
                    "规则已更换。请预测程序会把每件物品送到哪个桶。",
                    "Rule changed. Predict which bin the program sends each item to."),
    "msg.verify_bad": ("程式輸出是「{bin}」。再試一次。", "程序输出是「{bin}」。再试一次。",
                       "The program outputs: {bin} bin. Try again."),
    "msg.verify_ok": ("驗證成功！請測試下一件物品。", "验证成功！请测试下一件物品。",
                      "Verified! Test the next item."),
    "msg.missed": ("漏掉了一件物品，生命值減 1。", "漏掉了一件物品，生命值减 1。",
                   "You missed an item. −1 life."),
    "msg.nevermind": ("沒關係，下一件物品來了。", "没关系，下一件物品来了。",
                      "No problem — here comes the next item."),
    "msg.closish": ("差一點！看看小芽的提示，再選一次。", "差一点！看看小芽的提示，再选一次。",
                    "So close! Read Sprout's hint and try again."),
    "msg.rethink_mat": ("再想想：這件物品是用甚麼材料做的？", "再想想：这件物品是用什么材料做的？",
                        "Think again: what material is this item made of?"),
    "msg.rule_fixed": ("規則改好了！現在點一個桶，試試新規則。",
                       "规则改好了！现在点一个桶，试试新规则。",
                       "Rule fixed! Now click a bin to test the new rule."),
    "msg.look_again": ("再看一次物品的材料，選另一個桶。", "再看一次物品的材料，选另一个桶。",
                       "Look at the material again and pick another bin."),
    "msg.test_ok": ("測試成功！我們來看看下一件物品。", "测试成功！我们来看看下一件物品。",
                    "Test passed! Let's look at the next item."),
    "msg.bin_bad_bottle": ("這個桶不合適。看看膠樽是用甚麼做的。", "这个桶不合适。看看塑料瓶是用什么做的。",
                           "Not this bin. Look at what the bottle is made of."),
    "msg.bin_bad_pic": ("這個桶不合適。再看圖想一想。", "这个桶不合适。再看图想一想。",
                        "Not this bin. Look at the picture and think again."),
    "msg.right": ("答對了！", "答对了！", "Correct!"),
    "msg.fixed_try3": ("改好了！現在用三件物品試一試。", "改好了！现在用三件物品试一试。",
                       "Fixed! Now test it with three items."),

    # ---------- 除錯關卡（積木） ----------
    "dbg.if_item": ("如果物品是膠樽，就執行：", "如果物品是塑料瓶，就执行：",
                    "If the item is a bottle, do:"),
    "dbg.put_bin": ("放入：{bin}桶", "放入：{bin}桶", "Put in: {bin} bin"),
    "dbg.put_only": ("放入 {bin}", "放入 {bin}", "Put in {bin}"),
    "dbg.blocks": ("可用的積木", "可用的积木", "Available blocks"),
    "dbg.think": ("試想：如果條件正確，哪一部分指令需要改？",
                  "试想：如果条件正确，哪一部分指令需要改？",
                  "Think: if the condition is right, which part needs changing?"),
    "dbg.verify": ("驗證 {i}／{n}", "验证 {i}／{n}", "Check {i}/{n}"),
    "dbg.click_bin": ("點擊一個桶，預測程式的輸出。", "点击一个桶，预测程序的输出。",
                      "Click a bin to predict the program's output."),
    "dbg.if_word": ("如果", "如果", "IF"),
    "dbg.drag_block": ("拖一塊積木到紅框內，改變程式的輸出。",
                       "拖一块积木到红框内，改变程序的输出。",
                       "Drag a block into the red box to change the output."),
    "dbg.click_where": ("點一個桶，預測程式會把它送到哪裏。", "点一个桶，预测程序会把它送到哪里。",
                        "Click a bin to predict where the program sends it."),
    "dbg.hint": ("提示", "提示", "Hint"),
    "dbg.hint_r1": ("先看左側圖示：程式正在判斷哪件物品？", "先看左侧图示：程序正在判断哪件物品？",
                    "Look at the left icon: which item is the program checking?"),
    "dbg.hint_r2": ("把『如果』和『放入』分開看。哪一邊需要改？",
                    "把『如果』和『放入』分开看。哪一边需要改？",
                    "Separate “IF” from “PUT IN”. Which side needs changing?"),
    "dbg.hint_v1": ("先找出物品的材料，再想起你在前面幾關用過的規則。",
                    "先找出物品的材料，再想起你在前面几关用过的规则。",
                    "Find the material first, then recall the rules from earlier levels."),
    "dbg.hint_v2": ("用一句『如果……就……』預測程式的輸出，再點桶驗證。",
                    "用一句『如果……就……』预测程序的输出，再点桶验证。",
                    "Say an “if… then…” sentence to predict, then click a bin to check."),
    "dbg.card_step1": ("第 1 步：幫物品選對垃圾桶", "第 1 步：帮物品选对垃圾桶",
                       "Step 1: pick the right bin for the item"),
    "dbg.card_step2": ("第 2 步：點垃圾桶，試試新規則", "第 2 步：点垃圾桶，试试新规则",
                       "Step 2: click a bin to test the new rule"),
    "dbg.card_progress3": ("先改規則，再做 3 次測試", "先改规则，再做 3 次测试",
                           "Fix the rule, then run 3 tests"),
    "dbg.card_case_test": ("測試 {i}／3", "测试 {i}／3", "Test {i}/3"),
    "dbg.card_case_task": ("任務 {i}／3", "任务 {i}／3", "Task {i}/3"),
    "dbg.card_old_rule": ("舊規則：放進「{bin}」", "旧规则：放进「{bin}」", "Old rule: {bin} bin"),
    "dbg.card_where": ("它應該去哪裏？", "它应该去哪里？", "Where should it go?"),
    "dbg.card_click": ("點一下下面的桶", "点一下下面的桶", "Click a bin below"),

    # ---------- 第三、四關：分類機除錯流程 ----------
    # 流程是「觀察 → 找錯 → 修規則 → 重跑」。以下文案對應每個階段的提示。
    "flow.watching": ("分類機正在示範：看清楚每一件垃圾被送去哪個桶。",
                      "分类机正在示范：看清楚每一件垃圾被送去哪个桶。",
                      "The machine is sorting. Watch where each item goes."),
    "flow.running": ("規則改了，再跑一次分類機……", "规则改了，再跑一次分类机……",
                     "Rule changed — running the machine again…"),
    "flow.find": ("哪一件被送錯了？點一下它。", "哪一件被送错了？点一下它。",
                  "Which one went to the wrong bin? Click it."),
    "flow.this_ok": ("這一件其實分對了。找找看有紅叉的那一件。",
                     "这一件其实分对了。找找看有红叉的那一件。",
                     "This one is actually correct. Look for the red cross."),
    "flow.now_fix": ("{item}被送錯了。點一個桶，把這條規則改對。",
                     "{item}被送错了。点一个桶，把这条规则改对。",
                     "{item} went to the wrong bin. Click the right bin."),
    "flow.fix_bad": ("改成「{bin}」的話，{item}還是會走錯。想想它是用甚麼材料做的。",
                     "改成「{bin}」的话，{item}还是会走错。想想它是用什么材料做的。",
                     "With “{bin}”, {item} would still be wrong. What is it made of?"),
    "flow.fixed": ("規則改好了！再看看分類機跑一次。",
                   "规则改好了！再看看分类机跑一次。",
                   "Rule fixed! Watch the machine run again."),
    "flow.progress": ("已修好 {c}／{n} 條規則", "已修好 {c}／{n} 条规则",
                      "Rules fixed {c}/{n}"),
    "flow.still_bad": ("還有 {n} 件被送錯，繼續找。", "还有 {n} 件被送错，继续找。",
                       "Still {n} item(s) wrong — keep looking."),
    "flow.all_ok": ("全部 {n} 件都正確！分類機修好了。", "全部 {n} 件都正确！分类机修好了。",
                    "All {n} items correct — the machine works!"),
    "flow.machine": ("分類機", "分类机", "Sorting machine"),
    "flow.rule_of": ("規則：{item} → {bin}", "规则：{item} → {bin}",
                     "Rule: {item} → {bin}"),
    "flow.bad_rule": ("分類機把「{item}」送去了「{bin}」桶。",
                      "分类机把「{item}」送去了「{bin}」桶。",
                      "The machine sends “{item}” to the “{bin}” bin."),

    # ---------- 第 4 關：盲改規則表 ----------
    # 這一關刻意不逐件顯示對錯，改好之後按「我改好了」才一次過驗四件。
    "flow.watch_blind": ("第 4 關：冇人會逐件話你聽對錯。睇清楚規則表，自己核對。",
                         "第 4 关：没人会逐件告诉你对错。看清楚规则表，自己核对。",
                         "Level 4: nobody tells you which one is wrong. Read the rule table and check it yourself."),
    "flow.edit": ("規則表有錯。點一條規則，再點下面任何一個桶就可以改；改好按「我改好了」。",
                  "规则表有错。点一条规则，再点下面任何一个桶就可以改；改好按「我改好了」。",
                  "The rule table has mistakes. Click a rule, then click a bin to change it. Press “I've fixed it” when done."),
    "flow.pick_bin": ("已選「{mat}」。點下面一個桶，就會改這條規則的落點。",
                      "已选「{mat}」。点下面一个桶，就会改这条规则的落点。",
                      "“{mat}” selected. Click a bin to change where it goes."),
    "flow.rule_set": ("這條規則現在是「{mat} → {bin}」。改好就按「我改好了」。",
                      "这条规则现在是「{mat} → {bin}」。改好就按「我改好了」。",
                      "The rule is now “{mat} → {bin}”. Press “I've fixed it” when ready."),
    "flow.check_wrong": ("仲有 {n} 件送錯。睇清楚邊件錯，改好再按一次。",
                         "还有 {n} 件送错。看清楚哪件错，改好再按一次。",
                         "{n} item(s) still wrong. Check again, fix, then press the button once more."),
    "mat.paper": ("廢紙", "废纸", "Paper"),
    "mat.plastic": ("塑膠", "塑料", "Plastic"),
    "mat.metal": ("金屬", "金属", "Metal"),
    "mat.general": ("一般垃圾", "一般垃圾", "General waste"),

    # ---------- AI 學伴提示 ----------
    "aitip.title": ("小芽 · AI 學伴提示", "小芽 · AI 学伴提示", "Sprout · AI buddy hint"),
    "aitip.paper": ("看看它的材料：這是乾淨的紙嗎？", "看看它的材料：这是干净的纸吗？",
                    "Check the material: is it clean paper?"),
    "aitip.plastic": ("想想膠樽的材料：它是紙做的，還是膠做的？",
                      "想想塑料瓶的材料：它是纸做的，还是塑料做的？",
                      "Think about the bottle: paper or plastic?"),
    "aitip.metal": ("想一想：鋁是紙、膠，還是金屬？", "想一想：铝是纸、塑料，还是金属？",
                    "Think: is aluminium paper, plastic, or metal?"),
    "aitip.general": ("留意：這張紙巾已經用過，可以當乾淨廢紙嗎？",
                      "留意：这张纸巾已经用过，可以当干净废纸吗？",
                      "Note: this tissue is used — can it count as clean paper?"),
    "aitip.lv1_newspaper": ("報紙是印在紙上的。它和膠樽是同一種材料嗎？",
                            "报纸是印在纸上的。它和胶瓶是同一种材料吗？",
                            "Newspaper is printed on paper. Same material as a bottle?"),
    "aitip.lv1_box": ("看看紙箱的箱身：它是用厚紙板，還是用塑料做的？",
                      "看看纸箱的箱身：它是用厚纸板，还是用塑料做的？",
                      "Look at the box: thick cardboard or plastic?"),
    "aitip.lv1_book": ("翻開書想一想：書頁是用紙，還是用塑料做的？",
                       "翻开书想一想：书页是用纸，还是用塑料做的？",
                       "Open the book: are the pages paper or plastic?"),
    "aitip.lv1_drink": ("想想喝完的膠樽：樽身是用紙，還是用塑料做的？",
                        "想想喝完的胶瓶：瓶身是用纸，还是用塑料做的？",
                        "Think about the empty bottle: paper or plastic body?"),
    "aitip.lv1_shampoo": ("想想洗頭水樽的樽身：它像紙箱，還是像飲品膠樽？",
                          "想想洗发水瓶的瓶身：它像纸箱，还是像饮料瓶？",
                          "Is the shampoo bottle like a box, or like a drink bottle?"),

    # ---------- 課前任務 ----------
    "brief.title": ("教 AI 學伴分類", "教 AI 学伴分类", "Teach the AI buddy to sort"),
    "brief.sub": ("課前情境　·　預設 AI 示範", "课前情境　·　预设 AI 示范",
                  "Pre-lesson scenario · AI demo"),
    "brief.quote": ("「我猜膠樽要放入藍色廢紙桶。」", "「我猜塑料瓶要放入蓝色废纸桶。」",
                    "“I guess the bottle goes in the blue paper bin.”"),
    "brief.ask": ("它的判斷對嗎？先想一想，再和同伴說。",
                  "它的判断对吗？先想一想，再和同伴说。",
                  "Is it right? Think first, then tell your partner."),
    "brief.right": ("做得好！請說：如果是膠樽，就放入黃桶。",
                    "做得好！请说：如果是塑料瓶，就放入黄桶。",
                    "Well done! Say: if it's a bottle, put it in the yellow bin."),
    "brief.wrong": ("再想一想：這個膠樽是由甚麼材料製成的？",
                    "再想一想：这个塑料瓶是由什么材料制成的？",
                    "Think again: what material is this bottle made of?"),
    "brief.look": ("先看膠樽的材料，再點一個桶。", "先看塑料瓶的材料，再点一个桶。",
                   "Check the bottle's material, then click a bin."),
    "brief.go": ("進入第 0 關", "进入第 0 关", "Enter level 0"),

    # ---------- 反思 ----------
    "ref.title": ("給地球媽媽的三個發現", "给地球妈妈的三个发现",
                  "Three findings for Mother Earth"),
    "ref.sub": ("先口頭回答或寫在學習單上，再點卡片打勾。",
                "先口头回答或写在学习单上，再点卡片打勾。",
                "Answer aloud or on your worksheet, then tick the cards."),
    "ref.c1.t": ("分類", "分类", "Sorting"),
    "ref.c1.a": ("哪一件物品最容易放錯？", "哪一件物品最容易放错？", "Which item is easiest to get wrong?"),
    "ref.c1.b": ("你怎樣判斷它的類別？", "你怎样判断它的类别？", "How do you decide its category?"),
    "ref.c2.t": ("條件", "条件", "Conditions"),
    "ref.c2.a": ("用一句「如果……就……」", "用一句「如果……就……」", "Say one “if… then…” sentence"),
    "ref.c2.b": ("說出你修正的規則。", "说出你修正的规则。", "State the rule you fixed."),
    "ref.c3.t": ("驗證", "验证", "Verification"),
    "ref.c3.a": ("你用哪個例子測試規則？", "你用哪个例子测试规则？", "Which example did you test with?"),
    "ref.c3.b": ("結果與預測相同嗎？", "结果与预测相同吗？", "Did the result match your prediction?"),
    "ref.note": ("寫好後，可由老師帶領，用外部 AI 整理文字。",
                 "写好后，可由老师带领，用外部 AI 整理文字。",
                 "Afterwards your teacher can help you tidy the text with an AI tool."),
    "ref.button": ("返回選關", "返回选关", "Back to levels"),

    # ---------- 結算 ----------
    "result.last_win": ("地球媽媽得救了！", "地球妈妈得救了！", "Mother Earth is saved!"),
    "result.win": ("過關了！", "过关了！", "Level complete!"),
    "result.lose": ("地球媽媽需要你再試一次", "地球妈妈需要你再试一次", "Mother Earth needs another try"),
    "result.lose2": ("地球媽媽難過了，再試一次", "地球妈妈难过了，再试一次", "Mother Earth is sad — try again"),
    "result.detail_last": ("分類機四件全部正確，兩條錯誤規則都修好了。",
                           "分类机四件全部正确，两条错误规则都修好了。",
                           "All four items correct — both wrong rules are fixed."),
    "result.detail_3": ("三件物品全部正確，錯誤規則已修好。",
                        "三件物品全部正确，错误规则已修好。",
                        "All three items correct — the wrong rule is fixed."),
    "result.score": ("得分：{s}", "得分：{s}", "Score: {s}"),
    "result.score_retry": ("本次得分：{s}　｜　試試改變你的分類策略。",
                           "本次得分：{s}　｜　试试改变你的分类策略。",
                           "Score: {s} · Try a different sorting plan next time."),
    "result.first_fixed": ("分類機修好了！", "分类机修好了！", "The machine works!"),
    "result.next_reflect": ("開始反思", "开始反思", "Start reflection"),
    "result.back_teacher": ("返回教師模式", "返回教师模式", "Back to teacher mode"),
    "result.back_practice": ("返回練習模式", "返回练习模式", "Back to practice"),

    # ---------- 暫停 ----------
    "pause.title": ("暫停中", "暂停中", "Paused"),
    "pause.hint": ("按 P 或點「繼續」回到遊戲。", "按 P 或点「继续」回到游戏。",
                   "Press P or click Resume to continue."),

    # ---------- 練習模式（免 PIN，舊教師模式的試玩功能） ----------
    "practice.sub": ("任選一關自由試玩，練習結果不會計入學生進度。",
                     "任选一关自由试玩，练习结果不会计入学生进度。",
                     "Play any level freely. Practice results are not counted."),
    "practice.hint": ("想看成績與匯出 CSV，請用旁邊的「教師模式」。",
                      "想看成绩与导出 CSV，请用旁边的「教师模式」。",
                      "For scores and CSV export, use Teacher mode next to it."),

    # ---------- 教師模式 ----------
    "teacher.sub": ("任選一關試玩，練習結果不會計入學生進度。",
                    "任选一关试玩，练习结果不会计入学生进度。",
                    "Open any level. Practice results are not counted."),
    "teacher.slow_on": ("慢速：開", "慢速：开", "Slow: on"),
    "teacher.slow_off": ("慢速：關", "慢速：关", "Slow: off"),
    "teacher.report": ("查看小測報告", "查看小测报告", "Quiz report"),
    "teacher.reset": ("重置關卡", "重置关卡", "Reset levels"),
    "teacher.reset_confirm": ("再按一次「重置關卡」確認。", "再按一次「重置关卡」确认。",
                              "Press “Reset levels” again to confirm."),
    "teacher.reset_done": ("關卡進度已重置。小測成績仍保留。", "关卡进度已重置。小测成绩仍保留。",
                           "Level progress reset. Quiz scores kept."),
    "teacher.exported": ("已開始下載：{name}", "已开始下载：{name}", "Downloading: {name}"),
    "teacher.export_fail": ("匯出失敗。請關閉 Excel 中的 CSV，再試一次。",
                            "导出失败。请关闭 Excel 中的 CSV，再试一次。",
                            "Export failed. Close the CSV in Excel and try again."),

    # ---------- 教師登入（PIN） ----------
    "teacher.login_title": ("教師登入", "教师登录", "Teacher sign-in"),
    "teacher.pin_set": ("首次使用：設定 5 位數演示 PIN",
                        "首次使用：设置 5 位数演示 PIN",
                        "First time: set a 5-digit demo PIN"),
    "teacher.pin_ask": ("請輸入教師 PIN", "请输入教师 PIN", "Enter the teacher PIN"),
    "teacher.pin_placeholder": ("輸入 5 位數字", "输入 5 位数字", "Enter 5 digits"),
    "teacher.pin_hint": ("這裡是老師的設定頁，同學請回主選單。",
                         "这里是老师的设置页，同学请回主菜单。",
                         "Teachers only — students please go back."),
    "teacher.pin_wrong": ("密碼不正確，請再試一次。", "密码不正确，请再试一次。",
                          "Incorrect PIN. Please try again."),
    "teacher.pin_need5": ("請輸入 5 位數字。", "请输入 5 位数字。", "Please enter 5 digits."),
    "teacher.login_btn": ("登入", "登录", "Sign in"),

    # ---------- 初始化小測 ----------
    "teacher.reset_quiz_title": ("初始化小測", "初始化小测", "Reset quiz data"),
    "teacher.reset_quiz_line1": ("這會清除這台裝置的學生小測紀錄。",
                                 "这会清除这台设备的学生小测记录。",
                                 "This clears student quiz records on this device."),
    "teacher.reset_quiz_line2": ("之後匯出的 CSV 只包含新紀錄。",
                                 "之后导出的 CSV 只包含新记录。",
                                 "Later exports will only contain new records."),
    "teacher.reset_quiz_line3": ("要保留舊成績，請先把 CSV 移到別的資料夾。",
                                 "要保留旧成绩，请先把 CSV 移到别的文件夹。",
                                 "To keep old scores, move the CSV elsewhere first."),
    "teacher.reset_quiz_btn": ("確認清除", "确认清除", "Clear records"),
    "teacher.reset_quiz_done": ("小測已初始化。下一次作答會從第 1 次開始。",
                                "小测已初始化。下一次作答会从第 1 次开始。",
                                "Quiz data reset. The next attempt starts at 1."),
    "teacher.reset_quiz_fail": ("初始化失敗。請關閉 Excel 中的 CSV，再試一次。",
                                "初始化失败。请关闭 Excel 中的 CSV，再试一次。",
                                "Reset failed. Close the CSV in Excel and try again."),

    # ---------- 報告 ----------
    "report.head": ("學號　　　　　　　　作答次數　　　　　　　　最高分",
                    "学号　　　　　　　　作答次数　　　　　　　　最高分",
                    "Student ID · Attempts · Best score"),
    "report.empty": ("還沒有小測成績。", "还没有小测成绩。", "No quiz scores yet."),
    "report.prev": ("上一頁", "上一页", "Prev"),
    "report.next": ("下一頁", "下一页", "Next"),
    "report.export": ("匯出 CSV", "导出 CSV", "Export CSV"),
    "report.reset_quiz": ("初始化小測", "初始化小测", "Reset quiz"),
    "report.legend": ("每次作答各佔一行，CSV 由瀏覽器下載。",
                      "每次作答各占一行，CSV 由浏览器下载。",
                      "One row per attempt; the CSV downloads in the browser."),

    # ---------- 小測 ----------
    "quiz.title": ("課後小測", "课后小测", "Quiz"),
    "quiz.done_title": ("你完成了小測！", "你完成了小测！", "Quiz complete!"),
    "quiz.report_title": ("小測報告", "小测报告", "Quiz report"),
    "quiz.need_id": ("請輸入學號，例如 S001。", "请输入学号，例如 S001。", "Enter a student ID, e.g. S001."),
    "quiz.input_id": ("輸入學號，然後開始。", "输入学号，然后开始。", "Enter your student ID to start."),
    "quiz.info": ("共 5 題，每題 20 分；沒有學號直接按開始。",
                  "共 5 题，每题 20 分；没有学号直接按开始。",
                  "5 questions · 20 points each. No student ID? Just press Start."),
    "quiz.start": ("開始小測", "开始小测", "Start quiz"),
    # 沒填學號時按鈕改這句：手機打不到字，要讓學生一眼知道可以直接按。
    "quiz.start_guest": ("直接開始（訪客）", "直接开始（访客）", "Start as guest"),
    "quiz.see_result": ("看結果", "看结果", "See result"),
    "quiz.next_q": ("下一題", "下一题", "Next question"),
    "quiz.recorded": ("本次結果已記錄。選一關再練習吧！", "本次结果已记录。选一关再练习吧！",
                      "Result recorded. Pick a level to practise."),

    # ---------- 小測題目 ----------
    "q1.q": ("這個乾淨紙箱應該放哪個桶？", "这个干净纸箱应该放哪个桶？",
             "Which bin should this clean cardboard box go in?"),
    "q1.e": ("紙箱是用紙做的，放藍色廢紙桶。", "纸箱是用纸做的，放蓝色废纸桶。",
             "A cardboard box is paper — use the blue paper bin."),
    "q2.q": ("這個空膠樽應該放哪個桶？", "这个空塑料瓶应该放哪个桶？",
             "Which bin should this empty bottle go in?"),
    "q2.e": ("膠樽是塑料，放黃色膠樽桶。", "塑料瓶是塑料，放黄色桶。",
             "A bottle is plastic — use the yellow plastic bin."),
    "q3.q": ("喝完汽水後，這個空鋁罐要放哪個桶？", "喝完汽水后，这个空铝罐要放哪个桶？",
             "Which bin should this empty can go in?"),
    "q3.e": ("用材料來判斷：鋁是金屬，所以放棕色桶。", "用材料来判断：铝是金属，所以放棕色桶。",
             "Judge by material: aluminium is metal — use the brown bin."),
    "q4.q": ("這張用過的紙巾應該放哪個桶？", "这张用过的纸巾应该放哪个桶？",
             "Which bin should this used tissue go in?"),
    "q4.e": ("這張紙巾用過了，本課把它放綠色一般垃圾桶。", "这张纸巾用过了，本课把它放绿色一般垃圾桶。",
             "This tissue is used, so in this lesson we use the green general waste bin."),
    "q5.q": ("除錯：如果是膠樽，應把「放入廢紙」換成甚麼？",
             "调试：如果是塑料瓶，应把「放入废纸」换成什么？",
             "Debug: if it's a bottle, what should “put in paper” become?"),
    "q5.e": ("保留「如果是膠樽」，把動作改為放入黃桶。", "保留「如果是塑料瓶」，把动作改为放入黄桶。",
             "Keep “if it's a bottle”, change the action to put it in the yellow bin."),
}


def set_lang(code):
    """切換目前語言。不認得的代碼就維持原狀。"""
    global LANG
    if code in LANGS:
        LANG = code
    return LANG


def T(key, **kwargs):
    """取出目前語言的文案；有參數時做格式化，失敗就回退原文，不讓畫面崩掉。"""
    row = STRINGS.get(key)
    if not row:
        return key
    index = LANGS.index(LANG) if LANG in LANGS else 0
    text = row[index]
    if kwargs:
        try:
            return text.format(**kwargs)
        except (KeyError, IndexError, ValueError):
            return text
    return text


# 物品內部識別碼（沿用中文原名，不動邏輯）→ i18n key
ITEM_KEYS = {
    "飲品膠樽": "item.drink",
    "洗頭水樽": "item.shampoo",
    "報紙": "item.newspaper",
    "乾淨紙箱": "item.box",
    "乾淨書本": "item.book",
    "鋁罐": "item.can",
    "罐頭盒": "item.tincan",
    "用過的紙巾": "item.tissue",
}


def item_name(raw):
    """把物品內部名稱翻成目前語言的顯示名稱。"""
    return T(ITEM_KEYS.get(raw, raw)) if raw in ITEM_KEYS else raw


def bin_name(key):
    return T(f"bin.{key}")


def bin_symbol(key):
    return T(f"bin.{key}.sym")

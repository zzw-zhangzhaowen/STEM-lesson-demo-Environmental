"""本機存檔及小測彙總。

瀏覽器版改動（僅此三處，分類與計分邏輯與桌面版完全一致）：
1. 存檔優先寫入瀏覽器 localStorage；不可用時退回記憶體，絕不讓遊戲崩潰。
2. 桌面版仍然寫入使用者資料夾 SaveMotherEarth，方便教師直接查看 CSV。
3. 匯出 CSV 在瀏覽器內改為「觸發下載」，桌面版照舊寫檔。
"""
import csv
import io
import json
import re
from pathlib import Path

DATA = Path.home() / "SaveMotherEarth"
FIELDS = ("student_id", "attempts", "best_score")
STORAGE_KEY = "save_mother_earth_v1"


def _js_window():
    """pygbag 會把 JS 的 window 掛在 platform 模組上；桌面版取不到就是 None。"""
    try:
        import platform as pygbag_platform
        return getattr(pygbag_platform, "window", None)
    except Exception:
        return None


class Data:
    def __init__(self, folder=DATA):
        self.state = {"student_id": "", "unlocked_level": 0, "best_scores": {},
                      "settings": {"muted": False, "teacher_slow": False}}
        self.folder = None
        self.save_path = None
        self.quiz_path = None
        self._memory_rows = []
        self._memory_only = False

        # 先試瀏覽器 localStorage（純前端存檔，重新整理也不會丟）。
        if self._load_from_local_storage():
            self.folder = Path("/tmp/SaveMotherEarth")
            return

        # 再試寫入本機資料夾（桌面版走這條，教師可直接開 CSV）。
        try:
            self.folder = Path(folder)
            self.folder.mkdir(parents=True, exist_ok=True)
            self.save_path = self.folder / "save.json"
            self.quiz_path = self.folder / "quiz_results.csv"
            if self.save_path.exists():
                stored = json.loads(self.save_path.read_text(encoding="utf-8"))
                self._merge(stored)
            if self.quiz_path.exists():
                with self.quiz_path.open(newline="", encoding="utf-8-sig") as file:
                    self._memory_rows = list(csv.DictReader(file))
        except (OSError, ValueError):
            # 瀏覽器沙盒沒有寫入權限：退回記憶體模式，功能照樣可用。
            self._memory_only = True
            self.folder = None

    # ---------- 存讀 ----------
    def _merge(self, stored):
        for key in self.state:
            if key in stored and isinstance(stored[key], type(self.state[key])):
                self.state[key] = stored[key]
        self.state["unlocked_level"] = max(0, min(4, self.state["unlocked_level"]))

    def _load_from_local_storage(self):
        window = _js_window()
        if window is None:
            return False
        try:
            raw = window.localStorage.getItem(STORAGE_KEY)
        except Exception:
            return False
        if not raw:
            return False
        try:
            payload = json.loads(str(raw))
            self._merge(payload.get("state", {}))
            self._memory_rows = payload.get("rows", [])
            return True
        except ValueError:
            return False

    def _save_to_local_storage(self):
        window = _js_window()
        if window is None:
            return False
        try:
            payload = json.dumps({"state": self.state, "rows": self._memory_rows},
                                 ensure_ascii=False)
            window.localStorage.setItem(STORAGE_KEY, payload)
            return True
        except Exception:
            return False

    def save(self):
        if self._save_to_local_storage():
            return
        if self._memory_only or self.save_path is None:
            return
        try:
            temp = self.save_path.with_suffix(".tmp")
            temp.write_text(json.dumps(self.state, ensure_ascii=False, indent=2),
                            encoding="utf-8")
            temp.replace(self.save_path)
        except OSError:
            self._memory_only = True

    # ---------- 小測成績 ----------
    def rows(self):
        return self._memory_rows

    def write_rows(self, path, rows):
        """產生 CSV 文字；桌面版寫檔，瀏覽器版同時觸發下載。"""
        buffer = io.StringIO()
        writer = csv.DictWriter(buffer, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows(rows)
        text = buffer.getvalue()

        window = _js_window()
        if window is not None:
            try:
                # 用 Blob + 隱藏連結，讓老師在瀏覽器直接下載 CSV。
                escaped = json.dumps(text)  # 安全地把 CSV 內容塞進 JS 字串
                window.eval(
                    "(() => {"
                    f" const t = {escaped};"
                    "  const b = new Blob(['\\ufeff' + t], {type: 'text/csv;charset=utf-8'});"
                    "  const a = document.createElement('a');"
                    "  a.href = URL.createObjectURL(b);"
                    "  a.download = 'quiz_export.csv';"
                    "  document.body.appendChild(a); a.click(); a.remove();"
                    "})()"
                )
            except Exception:
                pass

        if path is not None:
            try:
                temp = Path(path).with_suffix(".tmp")
                temp.write_text(text, encoding="utf-8-sig")
                temp.replace(path)
            except OSError:
                pass
        return text

    def record(self, student_id, score):
        if not re.fullmatch(r"[A-Za-z0-9_-]{1,20}", student_id):
            raise ValueError("學號格式錯誤")
        rows = self.rows()
        for row in rows:
            if row["student_id"] == student_id:
                row["attempts"] = int(row["attempts"]) + 1
                row["best_score"] = max(int(row["best_score"]), score)
                break
        else:
            rows.append(dict(student_id=student_id, attempts=1, best_score=score))
        self.write_rows(self.quiz_path, rows)
        self.state["student_id"] = student_id
        self.save()

    def export(self):
        path = self.folder / "quiz_export.csv" if self.folder else None
        self.write_rows(path, self.rows())
        return path if path else Path("quiz_export.csv")

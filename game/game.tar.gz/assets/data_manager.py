"""本機存檔及小測紀錄。

瀏覽器版改動（僅此幾處，分類與計分邏輯與桌面版完全一致）：
1. 存檔優先寫入瀏覽器 localStorage；不可用時退回記憶體，絕不讓遊戲崩潰。
2. 桌面版仍然寫入使用者資料夾 SaveMotherEarth，方便教師直接查看 CSV。
3. 匯出 CSV 在瀏覽器內改為「觸發下載」，桌面版照舊寫檔。

小測成績存的是「逐次紀錄」（student_id, attempt_number, score），
報告畫面的「作答次數 / 最高分」由這份紀錄即時彙總，
所以同一份資料既能畫表格，也能匯出成每次一行的 CSV。
"""
import csv
import io
import json
import re
from pathlib import Path

DATA = Path.home() / "SaveMotherEarth"
FIELDS = ("student_id", "attempts", "best_score")
ATTEMPT_FIELDS = ("student_id", "attempt_number", "score")
STORAGE_KEY = "save_mother_earth_v1"
ID_PATTERN = re.compile(r"[A-Za-z0-9_-]{1,20}")


def _js_window():
    """pygbag 會把 JS 的 window 掛在 platform 模組上；桌面版取不到就是 None。"""
    try:
        import platform as pygbag_platform
        return getattr(pygbag_platform, "window", None)
    except Exception:
        return None


class Data:
    def __init__(self, folder=DATA):
        self.state = {"student_id": "", "demo_pin": "", "unlocked_level": 0,
                      "best_scores": {},
                      "settings": {"muted": False, "teacher_slow": False}}
        self.folder = None
        self.save_path = None
        self.quiz_path = None
        self.attempt_path = None
        self._memory_attempts = []
        self._memory_only = False

        # 先試瀏覽器 localStorage（純前端存檔，重新整理也不會丟）。
        if self._load_from_local_storage():
            self.folder = Path("/tmp/SaveMotherEarth")
            return

        # 再試寫入本機資料夾（桌面版走這條，教師可直接開 CSV）。
        try:
            self.folder = Path(folder)
            self.folder.mkdir(parents=True, exist_ok=True)
            self.save_path = self.folder / "save.json"
            self.quiz_path = self.folder / "quiz_results.csv"
            self.attempt_path = self.folder / "quiz_attempts.csv"
            if self.save_path.exists():
                stored = json.loads(self.save_path.read_text(encoding="utf-8"))
                self._merge(stored)
            if self.attempt_path.exists():
                with self.attempt_path.open(newline="", encoding="utf-8-sig") as file:
                    self._memory_attempts = self._clean_attempts(csv.DictReader(file))
            elif self.quiz_path.exists():
                # 舊版只存彙總表，升級時展開成逐次紀錄，免得老師的既有成績消失。
                with self.quiz_path.open(newline="", encoding="utf-8-sig") as file:
                    self._memory_attempts = self._expand_summary(csv.DictReader(file))
        except (OSError, ValueError):
            # 瀏覽器沙盒沒有寫入權限：退回記憶體模式，功能照樣可用。
            self._memory_only = True
            self.folder = None

    # ---------- 存讀 ----------
    def _merge(self, stored):
        for key in self.state:
            if key in stored and isinstance(stored[key], type(self.state[key])):
                self.state[key] = stored[key]
        self.state["unlocked_level"] = max(0, min(4, self.state["unlocked_level"]))
        pin = str(self.state.get("demo_pin") or "")
        self.state["demo_pin"] = pin if re.fullmatch(r"[0-9]{5}", pin) else ""

    def _load_from_local_storage(self):
        window = _js_window()
        if window is None:
            return False
        try:
            raw = window.localStorage.getItem(STORAGE_KEY)
        except Exception:
            return False
        if not raw:
            return False
        try:
            payload = json.loads(str(raw))
            self._merge(payload.get("state", {}))
            attempts = payload.get("attempts")
            if isinstance(attempts, list):
                self._memory_attempts = self._clean_attempts(attempts)
            else:
                # 舊版格式：只有 rows（彙總）。展開成逐次紀錄再繼續。
                self._memory_attempts = self._expand_summary(payload.get("rows") or [])
            return True
        except (ValueError, TypeError):
            return False

    def _save_to_local_storage(self):
        window = _js_window()
        if window is None:
            return False
        try:
            payload = json.dumps({"state": self.state, "attempts": self._memory_attempts},
                                 ensure_ascii=False)
            window.localStorage.setItem(STORAGE_KEY, payload)
            return True
        except Exception:
            return False

    def save(self):
        if self._save_to_local_storage():
            return
        if self._memory_only or self.save_path is None:
            return
        try:
            temp = self.save_path.with_suffix(".tmp")
            temp.write_text(json.dumps(self.state, ensure_ascii=False, indent=2),
                            encoding="utf-8")
            temp.replace(self.save_path)
        except OSError:
            self._memory_only = True

    # ---------- 逐次紀錄的清洗 / 相容 ----------
    def _clean_attempts(self, rows):
        """只留合法紀錄：學號符合格式、次數與分數都是整數、分數夾在 0–100。"""
        clean = []
        for row in rows:
            try:
                student_id = str(row["student_id"]).strip()
                number = int(row["attempt_number"])
                score = int(row["score"])
            except (KeyError, TypeError, ValueError):
                continue
            if not ID_PATTERN.fullmatch(student_id) or number < 1:
                continue
            clean.append({"student_id": student_id, "attempt_number": number,
                          "score": max(0, min(100, score))})
        clean.sort(key=lambda item: (item["student_id"], item["attempt_number"]))
        return clean

    def _expand_summary(self, rows):
        """把舊版「學號 / 次數 / 最高分」展開成逐次紀錄。

        舊資料沒有每一次的分數，只能把最高分沿用到每一次；
        升級後的資料都是逐次寫入，不會再有這個問題。
        """
        expanded = []
        for row in rows:
            try:
                student_id = str(row["student_id"]).strip()
                count = min(max(int(row.get("attempts") or 1), 1), 200)
                best = int(row.get("best_score") or 0)
            except (KeyError, TypeError, ValueError):
                continue
            if not ID_PATTERN.fullmatch(student_id):
                continue
            for number in range(1, count + 1):
                expanded.append({"student_id": student_id, "attempt_number": number,
                                 "score": max(0, min(100, best))})
        expanded.sort(key=lambda item: (item["student_id"], item["attempt_number"]))
        return expanded

    # ---------- 小測成績 ----------
    def rows(self):
        """把逐次紀錄彙總成報告要的「學號 / 作答次數 / 最高分」。"""
        summary = {}
        for attempt in self._memory_attempts:
            student_id = attempt["student_id"]
            row = summary.setdefault(student_id, {"student_id": student_id,
                                                  "attempts": 0, "best_score": 0})
            row["attempts"] = max(row["attempts"], attempt["attempt_number"])
            row["best_score"] = max(row["best_score"], attempt["score"])
        return [summary[key] for key in sorted(summary)]

    def export_rows(self):
        """匯出用：每次作答獨立一行；中間缺號補空分數，不讓行數對不上。"""
        scores = {(item["student_id"], item["attempt_number"]): item["score"]
                  for item in self._memory_attempts}
        rows = []
        for summary in self.rows():
            student_id = summary["student_id"]
            for number in range(1, summary["attempts"] + 1):
                rows.append({"student_id": student_id, "attempt_number": number,
                             "score": scores.get((student_id, number), "")})
        return rows

    def write_rows(self, path, rows, fields=FIELDS, download=False):
        """產生 CSV 文字；桌面版寫檔，瀏覽器版在 download=True 時觸發下載。

        只有教師按「匯出 CSV」才下載。交卷時寫入逐次紀錄不能下載，
        否則學生每考一次就跳一個檔案下載框。
        """
        buffer = io.StringIO()
        # 換行固定用 \n：csv 預設寫 \r\n，若再經 Windows 文字的 \n→\r\n 轉換，
        # 會變成 \r\r\n，Excel 打開就會每行之間多一個空行。
        writer = csv.DictWriter(buffer, fieldnames=fields, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)
        text = buffer.getvalue()

        window = _js_window()
        if window is not None and download:
            try:
                # 用 Blob + 隱藏連結，讓老師在瀏覽器直接下載 CSV。
                escaped = json.dumps(text)  # 安全地把 CSV 內容塞進 JS 字串
                window.eval(
                    "(() => {"
                    f" const t = {escaped};"
                    "  const b = new Blob(['\\ufeff' + t], {type: 'text/csv;charset=utf-8'});"
                    "  const a = document.createElement('a');"
                    "  a.href = URL.createObjectURL(b);"
                    "  a.download = 'quiz_export.csv';"
                    "  document.body.appendChild(a); a.click(); a.remove();"
                    "})()"
                )
            except Exception:
                pass

        if path is not None:
            try:
                temp = Path(path).with_suffix(".tmp")
                with temp.open("w", newline="", encoding="utf-8-sig") as file:
                    file.write(text)
                temp.replace(path)
            except OSError:
                pass
        return text

    def record(self, student_id, score):
        if not ID_PATTERN.fullmatch(student_id):
            raise ValueError("學號格式錯誤")
        previous = max([item["attempt_number"] for item in self._memory_attempts
                        if item["student_id"] == student_id] or [0])
        self._memory_attempts.append({"student_id": student_id,
                                      "attempt_number": previous + 1,
                                      "score": max(0, min(100, int(score)))})
        self._memory_attempts.sort(key=lambda item: (item["student_id"],
                                                     item["attempt_number"]))
        self.state["student_id"] = student_id
        # 桌面版順手留一份逐次紀錄檔，教師可以直接開。
        self.write_rows(self.attempt_path, self._memory_attempts, ATTEMPT_FIELDS)
        self.save()

    def export(self):
        """下載 quiz_export.csv：每次作答一行。"""
        path = self.folder / "quiz_export.csv" if self.folder else None
        self.write_rows(path, self.export_rows(), ATTEMPT_FIELDS, download=True)
        return Path("quiz_export.csv")

    def reset_quiz(self):
        """清空這台裝置的小測紀錄，下次作答從第 1 次開始。"""
        self._memory_attempts = []
        self.state["student_id"] = ""
        if self.folder is not None:
            for name in ("quiz_export.csv", "quiz_attempts.csv", "quiz_results.csv"):
                try:
                    (self.folder / name).unlink(missing_ok=True)
                except OSError:
                    # 匯出檔被 Excel 鎖住也照樣清紀錄；報告會即時反映清空結果。
                    pass
        self.save()

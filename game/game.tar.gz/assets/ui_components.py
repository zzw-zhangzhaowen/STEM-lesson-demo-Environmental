"""《地球媽媽拯救大作戰》圖像與 AI 學伴版。"""
import pygame
from game_levels import (Game, BINS, LEVELS, TESTS, ITEMS, WIDTH, HEIGHT,
                         INK, WHITE, ITEM_INTERVAL, beat_label)
from i18n import T, item_name, bin_name

NAVY = "#164343"
CREAM = "#fff9e7"
PALE = "#e2f3e5"
CORAL = "#d85f45"


class PictureGame(Game):
    def __init__(self):
        super().__init__()
        self.ai_checked = False
        self.ai_choice = None
        self.hint_step = 0
        self.reflect_done = set()
        self.ai_entry = pygame.Rect(330, 508, 340, 58)
        self.go = pygame.Rect(347, 553, 306, 54)
        self.hint_button = pygame.Rect(735, 25, 106, 44)
        self.cards = [pygame.Rect(96 + i * 274, 235, 260, 258) for i in range(3)]
        self.ai_bins = {"paper": pygame.Rect(249, 337, 210, 122),
                        "plastic": pygame.Rect(541, 337, 210, 122)}

    def start(self, level):
        super().start(level)
        self.hint_step = 0

    def handle(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            pos = event.pos
            if self.view in ("briefing", "reflection"):
                if self.back.collidepoint(pos):
                    self.view = "menu"
                elif self.mute.collidepoint(pos):
                    self.muted = not self.muted
                elif self.view == "briefing":
                    if self.go.collidepoint(pos) and self.ai_checked:
                        self.start(0)
                    else:
                        for key, area in self.ai_bins.items():
                            if area.collidepoint(pos):
                                self.ai_choice = key
                                self.ai_checked = key == "plastic"
                                self.play("right" if self.ai_checked else "wrong")
                elif self.go.collidepoint(pos):
                    self.view = "menu"
                else:
                    for index, card in enumerate(self.cards):
                        if card.collidepoint(pos):
                            if index in self.reflect_done:
                                self.reflect_done.remove(index)
                            else:
                                self.reflect_done.add(index)
                return
            if self.view == "play" and self.level == 3:
                if self.outcome == "win" and self.next.collidepoint(pos):
                    self.view = "reflection"
                    self.reflect_done.clear()
                    return
                if not self.outcome and self.hint_button.collidepoint(pos):
                    self.hint_step = min(2, self.hint_step + 1)
                    return
                previous = (self.stage, self.test_index)
                super().handle(event)
                if self.view == "play" and previous != (self.stage, self.test_index):
                    self.hint_step = 0
                return
        if event.type == pygame.MOUSEBUTTONUP and self.view == "play" and self.level == 3:
            previous_stage = self.stage
            super().handle(event)
            if self.stage != previous_stage:
                self.hint_step = 0
            return
        super().handle(event)

    def circle(self, color, center, radius):
        pygame.draw.circle(self.screen, color, center, radius)

    def line(self, color, first, last, width=3):
        pygame.draw.line(self.screen, color, first, last, width)

    def icon(self, key, center, size):
        """用幾何圖形繪製物件，圖示可隨畫面大小調整。"""
        x, y = center
        s = size
        def box(dx, dy, w, h, color, radius=5):
            self.rect(pygame.Rect(x + int(dx*s), y + int(dy*s),
                                  int(w*s), int(h*s)), color, radius)

        if key == "plastic":
            box(-.15, -.48, .30, .16, "#287ba3")
            box(-.13, -.34, .26, .19, "#7ed5e4")
            box(-.27, -.23, .54, .69, "#7ed5e4", 11)
            box(-.27, -.02, .54, .24, "#247ca8")
            box(-.15, -.16, .08, .12, WHITE)
            self.line("#e2f9ff", (x-int(s*.13), y+int(s*.10)), (x+int(s*.14), y+int(s*.10)), 2)
        elif key == "paper":
            box(-.33, -.40, .68, .81, "#79b1bf", 4)
            box(-.40, -.45, .68, .81, "#fff9e7", 4)
            box(-.30, -.32, .46, .12, "#3892a6")
            for row in range(3):
                box(-.30, -.09 + row*.12, .44, .04, "#8ba49c", 2)
        elif key == "metal":
            box(-.30, -.40, .60, .82, "#af627e", 9)
            box(-.30, -.17, .60, .35, "#bf3658", 3)
            pygame.draw.ellipse(self.screen, "#d7e8e8", (x-int(.30*s), y-int(.44*s), int(.60*s), int(.18*s)))
            pygame.draw.ellipse(self.screen, "#869fa6", (x-int(.10*s), y-int(.405*s), int(.21*s), int(.07*s)), 2)
            box(-.16, -.12, .07, .24, "#efadc0", 2)
        elif key == "general":
            points = [(-.42,.20),(-.32,-.28),(-.04,-.42),(.15,-.31),(.40,-.13),(.32,.31),(-.04,.42)]
            pygame.draw.polygon(self.screen, "#e9dfc4", [(x+int(a*s),y+int(b*s)) for a,b in points])
            self.line("#ada28c", (x-int(.27*s),y-int(.04*s)), (x+int(.09*s),y-int(.23*s)))
            self.line("#ada28c", (x+int(.12*s),y+int(.21*s)), (x+int(.26*s),y-int(.09*s)))
        elif key == "robot":
            box(-.44,-.31,.88,.66,"#8262b7",14)
            box(-.31,-.18,.62,.35,"#efe8ff",10)
            for side in (-1,1):
                self.circle("#453167", (x+side*int(.15*s), y-int(.015*s)), max(2,int(.045*s)))
            self.line("#453167",(x,y-int(.31*s)),(x,y-int(.47*s)))
            self.circle("#efb63c",(x,y-int(.47*s)),max(3,int(.07*s)))
        elif key == "bulb":
            self.circle("#f6c749",(x,y-int(.08*s)),int(.30*s))
            box(-.13,.10,.26,.25,"#a78445")
            self.line("#fff5b0",(x-int(.08*s),y-int(.20*s)),(x+int(.06*s),y-int(.25*s)),4)
        elif key == "check":
            self.circle("#40906b",(x,y),int(.40*s))
            pygame.draw.lines(self.screen, WHITE, False,
                              [(x-int(.20*s),y),(x-int(.06*s),y+int(.14*s)),
                               (x+int(.20*s),y-int(.15*s))], max(3,int(s*.075)))
        elif key == "cross":
            self.circle(CORAL,(x,y),int(.40*s))
            for sign in (-1,1):
                self.line(WHITE,(x-int(.15*s),y-sign*int(.15*s)),
                          (x+int(.15*s),y+sign*int(.15*s)),max(3,int(s*.065)))

    def item_icon(self, name, center, size):
        x, y = center
        if name == "乾淨紙箱":
            s = size
            self.rect((x-s//3, y-s//3, s*2//3, s*2//3), "#c8955f", 3)
            self.rect((x-s//12, y-s//3, s//6, s*2//3), "#ebbc7c", 0)
            self.line("#86603f", (x-s//3,y), (x+s//3,y), 2)
        elif name == "乾淨書本":
            self.rect((x-size//3,y-size//3,size*2//3,size*2//3), "#7463ae", 6)
            self.rect((x-size//4,y+size//6,size//2,size//8), "#fff4cf", 3)
            self.line("#ddd0ff",(x-size//5,y-size//4),(x-size//5,y+size//8),2)
        elif name == "洗頭水樽":
            self.rect((x-size//4,y-size//4,size//2,size*3//5), "#d08bbd", 9)
            self.rect((x-size//8,y-size//2,size//4,size//4), "#874579", 4)
            self.circle("#ffe9f7", (x,y+size//14), size//8)
        else:
            self.icon(ITEMS[name], center, size)

    def bin_art(self, key, area):
        name, _, color = BINS[key]
        x, y = area.centerx, area.y
        self.rect(area.move(0, 4), "#c1d8c8", 18)
        self.rect(area.inflate(-14, -7), color, 17)
        self.rect((area.x, y+4, area.w, 19), color, 8)
        self.rect((x-28, y+10, 56, 5), NAVY, 3)
        self.circle(CREAM, (x,y+50), 22)
        self.icon(key, (x,y+50), 34)
        self.text(name, x, y+89, 19, NAVY if key == "plastic" else WHITE, center=True)

    def draw_bins(self):
        for key, area in self.bins.items():
            self.bin_art(key, area)

    def draw_menu(self):
        self.earth((500, 102), 57)
        self.text(T("menu.title"), 500, 184, 54, center=True)
        self.text(T("menu.sub_adventure"), 500, 231, 22, center=True)
        for number, key in enumerate(("plastic", "paper", "metal", "bulb")):
            area = self.menu_rect(number)
            locked = number > self.unlocked
            self.rect(area.move(0, 4), "#c5dbcd")
            self.rect(area, "#f3f7ed" if locked else WHITE)
            self.circle(PALE, (area.x+49, area.centery), 28)
            self.icon(key,(area.x+49,area.centery),43)
            self.text(f"{number}　{T(f'lv.{number}')}",area.x+92,area.y+15,26)
            self.text(T("menu.locked") if locked else T("menu.start"),area.x+108,area.y+53,19)
        self.button(self.ai_entry, T("menu.ai_entry"))
        self.icon("robot", (self.ai_entry.x+40,self.ai_entry.centery),38)
        self.text(T("menu.hint_drag"),500,606,19,center=True)

    def draw_sort(self):
        interval = getattr(self, "interval", ITEM_INTERVAL)
        goal = T("goal.0") if self.level == 0 else T("goal.1") if self.level == 1 else T("goal.2_short")
        self.text(goal, 500, 235, 19, center=True)
        self.text(T("hud.beat" if self.level == 0 else "hud.answer_next", s=beat_label(interval)), 500, 266, 19,
                  "#4e7a68", center=True)
        track = pygame.Rect(21,304,958,86)
        self.rect(track.move(0,5),"#c0d6ca",24)
        self.rect(track,"#335b58",24)
        # 紋理隨 belt 向左滾動（拖動時也會動），讓「帶子沒有停」看得出來。
        offset = int(getattr(self, "belt", 0.0)) % 54
        for x in range(-54 + offset, 990, 54):
            pygame.draw.lines(self.screen,"#71958a",False,[(x+9,329),(x,346),(x+9,363)],3)
        self.draw_bins()
        if self.level == 0:
            x = self.bins["plastic"].centerx
            y = 436 + int(pygame.time.get_ticks()/120)%6
            pygame.draw.polygon(self.screen,"#d28b12",[(x-13,y),(x+13,y),(x,y+24)])
        # 黃色細條是本關節拍：走滿就換下一件，學生分類快也不會提前補貨。
        if not self.outcome:
            progress = min(getattr(self, "item_timer", 0.0) / interval, 1.0)
            self.rect(pygame.Rect(24, 308, max(4, int(952 * progress)), 6),
                      "#f2c14e", 3)
        if not self.outcome and not getattr(self, "item_resolved", False):
            name = self.sequence[self.item_index]
            self.rect(self.item.move(0,3),"#b7cec0")
            self.rect(self.item, CREAM)
            self.item_icon(name,(self.item.x+35,self.item.centery),48)
            self.text(item_name(name),self.item.x+110,self.item.centery,18,center=True)

    def draw_briefing(self):
        self.button(self.back,T("btn.back"))
        self.text(T("brief.title"),500,62,44,center=True)
        self.text(T("brief.sub"),500,111,19,center=True)
        self.icon("robot",(252,214),100)
        self.rect((321,151,473,121), WHITE, 22)
        self.text(T("brief.quote"),557,189,22,center=True)
        self.text(T("brief.ask"),557,233,22,center=True)
        self.icon("plastic",(500,309),57)
        for key, area in self.ai_bins.items():
            self.bin_art(key, area)
        if self.ai_choice:
            self.icon("check" if self.ai_checked else "cross",(500,493),46)
            message = T("brief.right") if self.ai_checked else T("brief.wrong")
        else:
            message = T("brief.look")
        self.text(message,500,527,22,center=True)
        if self.ai_checked:
            self.button(self.go,T("brief.go"))

    def draw_debug(self):
        if self.stage == "repair":
            self.icon("robot",(150,263),75)
            self.text(T("dbg.if_word"),300,222,22,center=True)
            self.icon("plastic",(300,266),57)
            self.rect(self.slot, "#ffdcd3")
            self.rect(self.slot,"#d45b45" if pygame.time.get_ticks()//420%2 else "#e68f7d",width=3)
            wrong = self.rules["plastic"]
            self.icon(wrong,(self.slot.x+43,self.slot.centery),41)
            self.text(T("dbg.put_only", bin=bin_name(wrong)),self.slot.x+143,self.slot.centery,22,center=True)
            self.icon("cross",(654,266),42)
            for key, area in self.options.items():
                self.rect(area,"#eff5ee")
                self.rect(area, "#84b8a6", width=2)
                self.icon(key,(area.x+34,area.centery),40)
                self.text(bin_name(key),area.x+113,area.centery,19,center=True)
            self.text(T("dbg.drag_block"),500,451,22,center=True)
            if self.block:
                x,y = pygame.mouse.get_pos()
                card = pygame.Rect(x-85,y-27,170,54)
                self.rect(card, CREAM)
                self.icon(self.block,(card.x+31,y),39)
                self.text(bin_name(self.block),card.x+102,y,19,center=True)
        else:
            self.draw_bins()
            if not self.outcome:
                name = TESTS[self.test_index]
                self.rect((394,218,212,174),WHITE,20)
                self.item_icon(name,(500,287),81)
                self.text(item_name(name),500,355,22,center=True)
                for index in range(len(TESTS)):
                    self.circle("#40906b" if index < self.test_index else "#c3d9c9",(467+33*index,411),8)
                self.text(T("dbg.click_where"),500,449,22,center=True)
        if not self.outcome:
            self.button(self.hint_button,T("dbg.hint"))
            if self.hint_step:
                if self.stage == "repair":
                    hint = T("dbg.hint_r1") if self.hint_step == 1 else T("dbg.hint_r2")
                else:
                    hint = T("dbg.hint_v1") if self.hint_step == 1 else T("dbg.hint_v2")
                y = 509 if self.stage == "repair" else 610
                self.rect((137,y-17,726,35),CREAM,9)
                self.text(hint,500,y,19,center=True)

    def draw_result(self):
        super().draw_result()
        if self.level == 3 and self.outcome == "win":
            self.button(self.next,T("result.next_reflect"))

    def draw_reflection(self):
        self.button(self.back,T("btn.back"))
        self.earth((500,87),45)
        self.text(T("ref.title"),500,158,44,center=True)
        self.text(T("ref.sub"),500,207,22,center=True)
        prompts = (("ref.c1","paper"),("ref.c2","bulb"),("ref.c3","check"))
        for index, (key, icon_key) in enumerate(prompts):
            area = self.cards[index]
            self.rect(area.move(0,5),"#bfd9ca")
            self.rect(area,WHITE)
            self.circle(PALE,(area.centerx,area.y+68),43)
            self.icon(icon_key,(area.centerx,area.y+68),65)
            self.text(T(f"{key}.t"),area.centerx,area.y+128,26,center=True)
            self.text(T(f"{key}.a"),area.centerx,area.y+174,19,center=True)
            self.text(T(f"{key}.b"),area.centerx,area.y+205,19,center=True)
            if index in self.reflect_done:
                self.icon("check",(area.right-23,area.y+25),32)
        self.text(T("ref.note"),500,527,19,center=True)
        self.button(self.go,T("ref.button"))

    def draw(self):
        self.screen.fill("#e7f4e7")
        pygame.draw.ellipse(self.screen,"#d4ead9",(-265,545,950,240))
        pygame.draw.ellipse(self.screen,"#d0e9d9",(543,569,800,185))
        if self.view == "briefing":
            self.draw_briefing()
        elif self.view == "reflection":
            self.draw_reflection()
        elif self.view == "menu":
            self.draw_menu()
        else:
            self.draw_header()
            if self.level == 3:
                self.draw_debug()
            else:
                self.draw_sort()
            self.text(T("hint.keys_play"),500,644,19,center=True)
            if self.outcome:
                self.draw_result()
        self.button(self.mute,T("btn.unmute") if self.muted else T("btn.mute"))
        pygame.display.flip()


if __name__ == "__main__":
    try:
        PictureGame().run()
    finally:
        pygame.quit()

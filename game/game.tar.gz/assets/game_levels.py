"""《地球媽媽拯救大作戰》：按 main.py 啟動。"""
from array import array
from math import pi, sin
from pathlib import Path
import os
import pygame

import i18n
from i18n import T, item_name, bin_name, bin_symbol

WIDTH, HEIGHT = 1000, 660
BG = "#eff7ed"
INK = "#193a35"
WHITE = "#ffffff"
GREEN = "#267753"

# 垃圾桶只固定顏色；名稱與符號隨語言變化，所以由 refresh_bins() 填進 BINS。
# BINS 是模組級 dict，其他模組 import 的是同一個物件，語言一換就處處同步。
BIN_COLORS = {
    "paper": "#3265ac",
    "plastic": "#f7c746",
    "metal": "#8a5340",
    "general": "#34795d",
}
BINS = {}

# 傳送帶節拍（秒）：每件物品在傳送帶上的最長時間。
# 前兩關留出辨認時間；除錯關不使用傳送帶。
ITEM_INTERVALS = {0: 5.0, 1: 4.0, 2: 3.0}
ITEM_INTERVAL = ITEM_INTERVALS[0]  # 預設值；相容舊的外部引用


def item_interval(level):
    """回傳該關的節拍秒數。"""
    return ITEM_INTERVALS.get(level, ITEM_INTERVAL)


def beat_label(seconds):
    """給三語文案用的秒數：整數不帶小數（5 而非 5.0）。"""
    return "%g" % seconds


def refresh_bins():
    """依目前語言重建 BINS：(名稱, 桶上單字, 顏色)。"""
    for key, color in BIN_COLORS.items():
        BINS[key] = (bin_name(key), bin_symbol(key), color)


refresh_bins()

ITEMS = {
    "飲品膠樽": "plastic", "洗頭水樽": "plastic",
    "報紙": "paper", "乾淨紙箱": "paper", "乾淨書本": "paper",
    "鋁罐": "metal", "罐頭盒": "metal",
    "用過的紙巾": "general",
}
LEVELS = {
    0: ("膠樽入門", ["飲品膠樽"], 35),
    1: ("分類練習", ["報紙", "飲品膠樽", "乾淨紙箱", "洗頭水樽", "乾淨書本"], 90),
    2: ("傳送帶挑戰", ["鋁罐", "報紙", "用過的紙巾", "洗頭水樽",
                      "罐頭盒", "乾淨紙箱", "飲品膠樽", "用過的紙巾",
                      "鋁罐", "乾淨書本", "飲品膠樽", "罐頭盒"], 155),
}
TESTS = ["飲品膠樽", "報紙", "鋁罐"]


HERE = Path(__file__).parent


def asset_path(relative):
    """回傳 assets 內檔案的路徑字串。

    WebAssembly 版的 SDL 不接受 Python 檔案物件（會拋
    "can't access resource on platform"），所以字體與圖片一律傳路徑字串，
    桌面版與瀏覽器版都讀得到同一個檔案。
    """
    return str(HERE / "assets" / relative)


def chinese_font(size):
    # 優先使用專案內附的繁中字體：桌面版與瀏覽器版顯示完全一致。
    # 注意：WebAssembly 版 SDL_ttf 不接受 Python 檔案物件，必須直接給路徑字串。
    bundled = HERE / "assets" / "NotoSansTC-subset.otf"
    if bundled.exists():
        return pygame.font.Font(str(bundled), size)

    # macOS 自帶的黑體也能顯示繁體中文字。
    mac_font = Path("/System/Library/Fonts/STHeiti Medium.ttc")
    if mac_font.exists():
        return pygame.font.Font(str(mac_font), size)
    windows_fonts = Path(os.environ.get("WINDIR", "C:/Windows")) / "Fonts"
    for filename in ("msjh.ttc", "msjh.ttf", "msyh.ttc", "mingliu.ttc"):
        path = windows_fonts / filename
        if path.exists():
            return pygame.font.Font(str(path), size)
    for name in ("microsoftjhenghei", "notosanscjktc", "pingfangtc",
                 "microsoftyahei", "simhei", "notosanscjksc"):
        path = pygame.font.match_font(name)
        if path:
            return pygame.font.Font(path, size)
    raise RuntimeError("請先安裝可顯示繁體中文的字體，例如 Noto Sans CJK TC。")


def make_sound(frequencies):
    """用正弦波即時合成音效；瀏覽器沒有音效裝置時回傳 None 而不是報錯。"""
    try:
        if not pygame.mixer.get_init():
            return None
        rate, _, channels = pygame.mixer.get_init()
        samples = array("h")
        for frequency in frequencies:
            count = int(rate * 0.11)
            for index in range(count):
                sample = int(4800 * (1 - index / count) * sin(2 * pi * frequency * index / rate))
                samples.extend([sample] * channels)
        return pygame.mixer.Sound(buffer=samples.tobytes())
    except (pygame.error, ValueError, OSError):
        return None


class Game:
    # 視窗尺寸。瀏覽器版只認「第一次」set_mode 的大小來建 canvas，
    # 所以由子類別決定，避免二次 set_mode 造成畫面被裁切。
    DISPLAY_SIZE = (WIDTH, HEIGHT)

    def __init__(self):
        try:
            pygame.mixer.pre_init(44100, -16, 1, 512)
        except pygame.error:
            pass
        pygame.init()
        self.screen = pygame.display.set_mode(self.DISPLAY_SIZE)
        pygame.display.set_caption(T("menu.title"))
        self.clock = pygame.time.Clock()
        self.fonts = {size: chinese_font(size) for size in (18, 19, 22, 26, 32, 44, 54)}
        self.sounds = {"right": make_sound([660, 880]), "wrong": make_sound([330, 220]),
                       "combo": make_sound([660, 880, 1100]), "win": make_sound([523, 659, 784, 1047])}
        self.unlocked = 0
        self.flash = 0
        self.muted = False
        self.running = True
        self.view = "menu"
        self.level = 0
        self.back = pygame.Rect(28, 24, 112, 45)
        self.mute = pygame.Rect(856, 24, 116, 45)
        self.next = pygame.Rect(510, 384, 218, 54)
        self.retry = pygame.Rect(272, 384, 218, 54)

    def play(self, kind):
        sound = self.sounds[kind]
        if sound and not self.muted:
            sound.play()

    def menu_rect(self, number):
        return pygame.Rect(130 + number % 2 * 380, 266 + number // 2 * 104, 360, 86)

    def start(self, level):
        self.level = level
        self.view = "play"
        self.outcome = None
        self.hp = 3
        self.score = self.combo = self.correct = 0
        self.dragging = False
        self.offset = (0, 0)
        self.flash = 0
        self.emotion = "happy"
        self.item = pygame.Rect(0, 0, 160, 65)
        categories = list(BINS) if level in (2, 3) else ["paper", "plastic"]
        width = 200
        gap = (WIDTH - len(categories) * width) // (len(categories) + 1)
        self.bins = {key: pygame.Rect(gap + i * (width + gap), 486, width, 112)
                     for i, key in enumerate(categories)}
        if level == 3:
            self.rules = {key: key for key in BINS}
            self.rules["plastic"] = "paper"
            self.stage = "repair"
            self.test_index = 0
            self.block = None
            self.slot = pygame.Rect(380, 237, 240, 58)
            self.options = {key: pygame.Rect(78 + i * 216, 354, 198, 60)
                            for i, key in enumerate(("paper", "plastic", "metal", "general"))}
            self.message = T("msg.inspect_rule")
        else:
            _, sequence, self.speed = LEVELS[level]
            self.sequence = sequence
            self.item_index = 0
            self.interval = item_interval(level)  # 本關節拍（秒）
            self.belt = 0.0          # 傳送帶紋理的滾動量，與物品位置分開計算
            self.spawn()
            self.message = T("msg.lv0_intro") if level == 0 else T("msg.drag_how")

    def spawn(self):
        # 教程物品先出現在視線中央，之後沿傳送帶往左移動。
        # item_x0 / item_timer 讓「物品位置」與「本關節拍」綁在一起。
        self.item_x0 = 600.0 if self.level == 0 else 810.0
        self.item_x = self.item_x0
        self.item_timer = 0.0
        self.item_resolved = False
        self.item.topleft = (int(self.item_x), 283)

    def finish(self, won):
        self.outcome = "win" if won else "retry"
        self.dragging = False
        if won:
            self.unlocked = max(self.unlocked, min(self.level + 1, 3))
            self.play("win")

    def feedback(self, right):
        self.emotion = "happy" if right else "sad"
        self.flash = 1.05
        self.play("right" if right else "wrong")

    def check_goal(self):
        """分類正確後馬上判定過關，不必等下一個節拍。"""
        if ((self.level == 0 and self.correct >= 1) or
                (self.level == 1 and self.correct >= 5) or
                (self.level == 2 and self.score >= 150 and self.hp > 0)):
            self.finish(True)
            return True
        return False

    def advance_item(self):
        """切換到下一件物品，或在題目用完時結算。"""
        self.item_index += 1
        if self.item_index == len(self.sequence):
            if self.level == 2:
                self.finish(False)
                return
            # 基礎關可以繼續練習，直到成功分類五次。
            self.item_index = 0
        self.spawn()

    def drop_item(self):
        # 用物品的中心點判斷它落在哪一個桶。
        target = next((key for key, rect in self.bins.items()
                       if rect.collidepoint(self.item.center)), None)
        if target is None:
            self.item.topleft = (int(self.item_x), 283)
            self.message = T("msg.not_in_bin")
            return

        name = self.sequence[self.item_index]
        if target == ITEMS[name]:
            self.correct += 1
            self.combo += 1
            bonus = 5 if self.level == 2 and self.combo >= 3 else 0
            self.score += 10 + bonus
            self.feedback(True)
            if bonus:
                self.play("combo")
            self.message = T("msg.correct") if not bonus else T("msg.combo", c=self.combo)
            if self.level == 0:
                self.message += T("msg.wait_next", s=beat_label(self.interval))
            self.item_resolved = True
            self.check_goal()
        else:
            self.combo = 0
            self.feedback(False)
            self.message = T("msg.wrong", item=item_name(name), bin=bin_name(ITEMS[name]))
            if self.level > 0:
                self.hp -= 1
            self.item.topleft = (int(self.item_x), 283)
            if self.hp <= 0:
                self.finish(False)

        if self.level in (1, 2) and not self.outcome:
            self.advance_item()
            return True
        return False

    def repair(self, key):
        # 積木代表分類程式的輸出。先用膠樽執行一次改過的規則。
        self.rules["plastic"] = key
        if self.rules["plastic"] != "plastic":
            self.feedback(False)
            self.message = T("msg.rule_bad", bin=bin_name(key))
            return
        self.stage = "verify"
        self.feedback(True)
        self.message = T("msg.rule_ok")

    def verify(self, chosen):
        category = ITEMS[TESTS[self.test_index]]
        # 這裏真的執行分類規則，再把程式結果與正確分類比較。
        actual = self.rules[category]
        if chosen != actual or actual != category:
            self.feedback(False)
            self.message = T("msg.verify_bad", bin=bin_name(actual))
            return
        self.feedback(True)
        self.score += 10
        self.test_index += 1
        if self.test_index == len(TESTS):
            self.finish(True)
        else:
            self.message = T("msg.verify_ok")

    def handle(self, event):
        if event.type == pygame.QUIT:
            self.running = False
            return
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                self.view = "menu"
                self.dragging = False
            elif event.key == pygame.K_r and self.view == "play":
                self.start(self.level)
            return

        if event.type == pygame.MOUSEMOTION:
            if self.view == "play" and self.dragging and self.level != 3:
                self.item.topleft = (event.pos[0] - self.offset[0], event.pos[1] - self.offset[1])
            return
        if event.type not in (pygame.MOUSEBUTTONDOWN, pygame.MOUSEBUTTONUP) or event.button != 1:
            return

        pos = event.pos
        if event.type == pygame.MOUSEBUTTONDOWN:
            if self.mute.collidepoint(pos):
                self.muted = not self.muted
            elif self.view == "menu":
                for number in range(self.unlocked + 1):
                    if self.menu_rect(number).collidepoint(pos):
                        self.start(number)
                        break
            elif self.back.collidepoint(pos):
                self.view = "menu"
                self.dragging = False
            elif self.outcome:
                if self.retry.collidepoint(pos):
                    self.start(self.level)
                elif self.next.collidepoint(pos):
                    if self.outcome == "win" and self.level < 3:
                        self.start(self.level + 1)
                    else:
                        self.view = "menu"
            elif self.level != 3 and not getattr(self, "item_resolved", False) and self.item.collidepoint(pos):
                self.dragging = True
                self.offset = (pos[0] - self.item.x, pos[1] - self.item.y)
            elif self.level == 3 and self.stage == "repair":
                self.block = next((key for key, rect in self.options.items()
                                   if rect.collidepoint(pos)), None)
            elif self.level == 3 and self.stage == "verify":
                for key, rect in self.bins.items():
                    if rect.collidepoint(pos):
                        self.verify(key)
                        break
        elif self.view == "play" and not self.outcome:
            if self.level != 3 and self.dragging:
                self.dragging = False
                self.item.topleft = (pos[0] - self.offset[0], pos[1] - self.offset[1])
                self.drop_item()
            elif self.level == 3 and self.block is not None:
                block = self.block
                self.block = None
                if self.slot.collidepoint(pos):
                    self.repair(block)

    def update(self, seconds):
        self.flash = max(0, self.flash - seconds)
        if self.view != "play" or self.outcome or self.level == 3:
            return

        # 拖動物品時，傳送帶和計時器仍繼續運作。
        self.belt = getattr(self, "belt", 0.0) + self.speed * seconds
        self.item_timer = getattr(self, "item_timer", 0.0) + seconds

        # 物品從右往左移動，逾時由 tick_item 處理。
        # 位置由計時器算，而不是累加速度，拖住物品也擋不住下一件出場。
        interval = getattr(self, "interval", ITEM_INTERVAL)
        progress = min(self.item_timer / interval, 1.0)
        self.item_x = self.item_x0 - (self.item_x0 + self.item.width + 20) * progress
        if not self.dragging and not self.item_resolved:
            self.item.x = int(self.item_x)

        if self.item_timer >= interval:
            self.tick_item()

    def tick_item(self):
        """節拍到：不管這件有沒有分類好，都讓下一件準時出場。"""
        if self.dragging:
            # 學生還拖著：若此刻正壓在某個桶上，仍算一次投放；否則當漏接。
            target = next((key for key, rect in self.bins.items()
                           if rect.collidepoint(self.item.center)), None)
            self.dragging = False
            if target is not None:
                advanced = self.drop_item()
                if advanced or self.outcome:
                    return
            elif not self.item_resolved:
                self.miss_item()
                if self.outcome:
                    return
        elif not self.item_resolved:
            self.miss_item()
            if self.outcome:
                return
        self.advance_item()

    def miss_item(self):
        """一件物品被傳送帶送走：斷連擊、第 2 關扣血（換件由 tick_item 統一做）。"""
        self.combo = 0
        if self.level == 2:
            self.hp -= 1
            self.feedback(False)
            self.message = T("msg.missed")
            if self.hp == 0:
                self.finish(False)
                return
        else:
            self.message = T("msg.nevermind")
        # 不在這裡 spawn：節拍到的那一刻由 tick_item() 統一換件。

    def rect(self, rect, color, radius=14, width=0):
        pygame.draw.rect(self.screen, color, rect, width=width, border_radius=radius)

    def text(self, value, x, y, size=22, color=INK, center=False):
        surface = self.fonts[size].render(value, True, color)
        area = surface.get_rect(center=(x, y)) if center else surface.get_rect(topleft=(x, y))
        self.screen.blit(surface, area)

    def button(self, rect, label, active=True):
        self.rect(rect, GREEN if active else "#dce7dc")
        self.text(label, *rect.center, 22, WHITE if active else "#4e655b", center=True)

    def earth(self, center, radius, happy=True):
        x, y = center
        pygame.draw.circle(self.screen, "#4298cd", center, radius)
        land = [(x-radius//2, y-radius//2), (x-radius//8, y-radius*3//4),
                (x+radius//4, y-radius//4), (x-radius//8, y+radius//5),
                (x-radius//2, y+radius//4)]
        pygame.draw.polygon(self.screen, "#75cf88", land)
        pygame.draw.circle(self.screen, "#75cf88", (x+radius//2, y+radius//4), radius//4)
        for side in (-1, 1):
            pygame.draw.circle(self.screen, INK, (x+side*radius//4, y-radius//9), max(2, radius//15))
        spread = radius//4
        middle = y + radius//5 + (radius//9 if happy else -radius//9)
        pygame.draw.lines(self.screen, INK, False,
                          [(x-spread, y+radius//5), (x, middle), (x+spread, y+radius//5)], 3)

    def heart(self, x, y, active):
        color = "#d94e56" if active else "#d8e1da"
        pygame.draw.circle(self.screen, color, (x-5, y), 6)
        pygame.draw.circle(self.screen, color, (x+5, y), 6)
        pygame.draw.polygon(self.screen, color, [(x-11, y+1), (x+11, y+1), (x, y+12)])

    def draw_menu(self):
        self.earth((500, 94), 52)
        self.text(T("menu.title"), 500, 181, 54, center=True)
        self.text(T("menu.sub_game"), 500, 226, 26, center=True)
        for number in range(4):
            locked = number > self.unlocked
            suffix = T("menu.locked_suffix") if locked else ""
            self.button(self.menu_rect(number),
                        T("menu.level", n=number, title=T(f"lv.{number}")) + suffix, not locked)
        self.text(T("menu.hint_pick"), 500, 555, 22, center=True)
        self.text(T("menu.hint_keys"), 500, 603, 19, center=True)

    def draw_header(self):
        self.button(self.back, T("btn.back"))
        title = T(f"lv.{self.level}")
        self.text(T("menu.level", n=self.level, title=title), 500, 45, 32, center=True)
        self.rect(pygame.Rect(28, 83, 944, 78), WHITE)
        self.earth((72, 122), 29, self.emotion == "happy")
        self.text(T("hud.hp"), 113, 111)
        for index in range(3):
            self.heart(200 + index * 33, 120, index < self.hp)
        if self.level == 1:
            self.text(T("hud.sorted", c=self.correct), 500, 123, 22, center=True)
        elif self.level == 2:
            combo_color = "#ac471c" if self.combo >= 3 and int(self.flash * 10) % 2 else INK
            self.text(T("hud.combo", c=self.combo), 500, 123, 26, combo_color, center=True)
        self.text(T("hud.score", s=self.score), 842, 123, 26, center=True)
        self.text(self.message, 500, 190, 22, center=True)

    def draw_bins(self):
        for key, area in self.bins.items():
            name, symbol, color = BINS[key]
            ink = INK if key == "plastic" else WHITE
            self.rect(area, color)
            pygame.draw.line(self.screen, ink, (area.left+18, area.top+16),
                             (area.right-18, area.top+16), 2)
            self.text(symbol, area.centerx, area.top+48, 32, ink, center=True)
            self.text(name, area.centerx, area.top+88, 22, ink, center=True)

    def draw_sort(self):
        goal = T("goal.0") if self.level == 0 else T("goal.1") if self.level == 1 else T("goal.2")
        self.text(T("goal.label", goal=goal), 500, 235, 19, center=True)
        self.rect(pygame.Rect(0, 308, WIDTH, 74), "#3d5d58", 0)
        # 條紋用 belt 而不是 item_x：拖動物品時帶子仍然繼續滾動。
        offset = int(getattr(self, "belt", 0.0)) % 58
        for x in range(-58 + offset, WIDTH, 58):
            pygame.draw.line(self.screen, "#69847d", (x, 319), (x, 369), 3)
        self.draw_bins()
        if self.level == 0:
            pygame.draw.polygon(self.screen, "#d28b12", [(715, 438), (745, 438), (730, 469)])
        if not self.outcome and not getattr(self, "item_resolved", False):
            name = self.sequence[self.item_index]
            self.rect(self.item, WHITE)
            self.rect(self.item, "#75b68f", width=3)
            self.text(item_name(name), *self.item.center, 18 if i18n.LANG == "en" else 22, center=True)

    def draw_debug(self):
        if self.stage == "repair":
            # 上一行是條件，下一行的彩色區域是可被替換的指令。
            self.text(T("dbg.if_item"), 500, 219, 19, center=True)
            self.rect(self.slot, "#ffe0dc")
            outline = "#b3473d" if pygame.time.get_ticks() // 350 % 2 else "#d68f88"
            self.rect(self.slot, outline, width=3)
            self.text(T("dbg.put_bin", bin=bin_name(self.rules['plastic'])),
                      *self.slot.center, 22, center=True)
            self.text(T("dbg.blocks"), 500, 329, 19, center=True)
            for key, rect in self.options.items():
                self.button(rect, T("dbg.put_bin", bin=bin_name(key)))
            self.text(T("dbg.think"), 500, 478, 22, center=True)
            if self.block:
                card = pygame.Rect(0, 0, 198, 60)
                card.center = pygame.mouse.get_pos()
                self.button(card, T("dbg.put_bin", bin=bin_name(self.block)))
        else:
            self.draw_bins()
            if not self.outcome:
                self.text(T("dbg.verify", i=self.test_index + 1, n=len(TESTS)), 500, 245, 26, center=True)
                self.rect(pygame.Rect(345, 282, 310, 82), WHITE)
                self.text(item_name(TESTS[self.test_index]), 500, 323, 32, center=True)
                self.text(T("dbg.click_bin"), 500, 414, 22, center=True)

    def draw_result(self):
        shade = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        shade.fill((20, 40, 35, 115))
        self.screen.blit(shade, (0, 0))
        self.rect(pygame.Rect(218, 202, 564, 265), WHITE)
        won = self.outcome == "win"
        # 第 4 關是瀏覽器版新增的最後一關，贏了同樣算「地球媽媽得救」。
        if won and self.level in (3, 4):
            title = T("result.last_win")
        elif won:
            title = T("result.win")
        else:
            title = T("result.lose")
        self.text(title, 500, 257, 32, center=True)
        if won and self.level == 4:
            detail = T("result.detail_last")
        elif won and self.level == 3:
            detail = T("result.detail_3")
        elif won:
            detail = T("result.score", s=self.score)
        else:
            detail = T("result.score_retry", s=self.score)
        self.text(detail, 500, 324, 22, center=True)
        self.button(self.retry, T("btn.retry"))
        self.button(self.next, T("btn.next") if won and self.level < 3 else T("btn.back_levels"))

    def draw(self):
        self.screen.fill(BG)
        if self.view == "menu":
            self.draw_menu()
        else:
            self.draw_header()
            if self.level == 3:
                self.draw_debug()
            else:
                self.draw_sort()
            self.text(T("hint.keys_play"), 500, 631, 19, center=True)
            if self.outcome:
                self.draw_result()
        self.button(self.mute, T("btn.unmute") if self.muted else T("btn.mute"))
        pygame.display.flip()

    def run(self):
        while self.running:
            seconds = min(self.clock.tick(60) / 1000, 0.05)
            for event in pygame.event.get():
                self.handle(event)
            if self.running:
                self.update(seconds)
                self.draw()


if __name__ == "__main__":
    try:
        Game().run()
    finally:
        pygame.quit()

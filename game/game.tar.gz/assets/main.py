"""最終版遊戲入口。

瀏覽器版改動只有三處：
1. 主迴圈改成 async（pygbag / WebAssembly 需要讓出控制權給瀏覽器）。
2. 字體與圖片改為傳路徑字串（wasm 版 SDL 不接受 Python 檔案物件）。
3. 其餘關卡、計分、除錯邏輯與桌面版完全一致。
"""
from pathlib import Path
import asyncio
import os
import re
import traceback

try:
    import pygame
    from data_manager import Data
    from game_levels import (BINS, ITEMS, LEVELS, TESTS, WIDTH, HEIGHT, WHITE, INK,
                             asset_path, refresh_bins)
    from ui_components import PictureGame, CREAM, PALE
    import i18n
    from i18n import T, item_name, bin_name, set_lang
except Exception:  # 匯入階段出錯時，至少讓畫面上看得到原因
    print(traceback.format_exc())
    try:
        import platform as _browser
        _browser.window.document.title = "IMPORT-ERR: " + traceback.format_exc().splitlines()[-1][:150]
    except Exception:
        pass
    raise

LEVELS[2][1].extend(["用過的紙巾", "鋁罐", "飲品膠樽", "報紙"])

# 第三、四關「分類機」的初始局面：(規則表, 送進機器的物品)。
# 規則表記的是「物品類別 → 程式把它送去哪個桶」，壞掉的值就是刻意寫錯的那一格。
#
# 第 3 關：只有 1 條規則壞，3 件物品之中 1 件出錯 —— 讓學生先學會「看結果找錯處」。
# 第 4 關：2 條規則壞，散在 4 件物品裡，另外 2 件其實分對 —— 學生要自己分辨，
#          不能「見到紅叉就亂改」，也不能動到本來正確的規則。
#
# 有趣的地方：第 4 關把 plastic 修好之後，鋁罐的落點會由「廢紙」變成「膠樽」，
# 仍然錯，但錯法變了 —— 學生會親眼見到「改一條規則，會影響另一件物品」。
MACHINE_CASES = {
    3: ({"plastic": "paper", "paper": "paper",
         "metal": "metal", "general": "general"},
        ["飲品膠樽", "報紙", "鋁罐"]),
    4: ({"plastic": "paper", "paper": "paper",
         "metal": "plastic", "general": "general"},
        ["飲品膠樽", "報紙", "鋁罐", "用過的紙巾"]),
}

# 卡通地球的大陸輪廓（0~1 歸一化座標）。
# 刻意避開臉部（眼睛在 x 0.31~0.69、y 0.35~0.53），其餘貼著圓邊，
# 這樣小尺寸時仍然一眼看得出「藍色海洋 + 綠色陸地」而不是一塊髒色。
EARTH_LANDS = (
    # 左上：從左邊緣伸進來的歐亞大陸（座標刻意超出 0~1，交給圓形遮罩裁掉）
    ((-0.06, 0.22), (0.05, 0.13), (0.18, 0.09), (0.30, 0.11), (0.38, 0.18),
     (0.33, 0.26), (0.24, 0.30), (0.20, 0.38), (0.09, 0.40), (-0.04, 0.33)),
    # 右上：從頂邊垂下來的亞洲
    ((0.50, 0.02), (0.63, -0.04), (0.77, 0.01), (0.90, 0.09), (0.99, 0.20),
     (0.86, 0.24), (0.74, 0.26), (0.64, 0.20), (0.54, 0.12)),
    # 右邊緣中段的小島
    ((0.85, 0.34), (0.99, 0.32), (1.03, 0.44), (0.94, 0.51), (0.84, 0.45)),
    # 左下：南美那條窄長的陸地，從左邊緣往下垂
    ((0.02, 0.50), (0.16, 0.47), (0.25, 0.56), (0.27, 0.70), (0.18, 0.79), (0.07, 0.73)),
    # 底部：從底邊上來的陸塊
    ((0.55, 0.87), (0.70, 0.80), (0.83, 0.86), (0.86, 1.02), (0.60, 1.04)),
)

# 卡通地球的配色。答錯時整體轉灰藍，但保留藍綠辨識度，免得學生認不出是同一個地球。
EARTH_PALETTE = {
    True:  {"sea": "#35b8e8", "land": "#4fbe58", "ink": "#1f2d2a", "blush": "#8fd8f2"},
    False: {"sea": "#7fb2cd", "land": "#8fb894", "ink": "#3d4a48", "blush": "#b9d6e4"},
}


def earth_surface(size, happy=True):
    """畫一個卡通地球（藍海 + 綠陸 + 大眼 + 微笑），回傳 Surface。

    先在 4 倍尺寸上畫、再 smoothscale 縮小：wasm 版 SDL 沒有 aacircle，
    這招能讓邊線在任何縮放比例下都不出現鋸齒。
    """
    size = max(16, int(size))
    ss = 4
    w = size * ss
    surf = pygame.Surface((w, w), pygame.SRCALPHA)
    palette = EARTH_PALETTE[bool(happy)]
    ink, land, sea, blush = palette["ink"], palette["land"], palette["sea"], palette["blush"]

    ring = max(3, int(w * 0.030))
    r = w // 2 - ring // 2
    cx = cy = w // 2
    pygame.draw.circle(surf, sea, (cx, cy), r)

    # 陸地先畫在獨立圖層，再用圓形遮罩裁掉圓外部分。
    # 這樣大陸會「延伸出球面邊緣」，看起來是包在球上的地圖，
    # 而不是幾塊漂在海中央的綠色石頭。
    land_layer = pygame.Surface((w, w), pygame.SRCALPHA)
    land_edge = max(2, int(w * 0.010))
    for poly in EARTH_LANDS:
        pts = [(int(x * w), int(y * w)) for x, y in poly]
        pygame.draw.polygon(land_layer, land, pts)
        pygame.draw.polygon(land_layer, ink, pts, land_edge)
    mask = pygame.Surface((w, w), pygame.SRCALPHA)
    pygame.draw.circle(mask, (255, 255, 255, 255), (cx, cy), r)
    land_layer.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
    surf.blit(land_layer, (0, 0))

    # 外圈最後畫，把陸地被裁開的邊緣蓋成乾淨的球體輪廓。
    pygame.draw.circle(surf, ink, (cx, cy), r, ring)

    # 眼睛：大黑圓 + 右上角白色高光。太小的尺寸省掉高光，免得糊成一粒。
    eye_r = max(3, int(w * 0.088))
    eye_y = int(w * 0.44)
    for ex in (0.395, 0.605):
        ecx = int(w * ex)
        pygame.draw.circle(surf, ink, (ecx, eye_y), eye_r)
        if size >= 44:
            pygame.draw.circle(surf, "#ffffff",
                               (ecx + int(eye_r * 0.32), eye_y - int(eye_r * 0.34)),
                               max(2, int(eye_r * 0.40)))

    # 眼睛下方兩撇腮紅；只有大圖才畫，小圖會變成雜點。
    if size >= 76:
        for sx in (0.285, 0.715):
            for k in (0, 1):
                bx = int(w * sx) + k * int(w * 0.030)
                by = int(w * 0.545)
                pygame.draw.line(surf, blush, (bx, by), (bx + int(w * 0.018), by + int(w * 0.028)),
                                 max(2, int(w * 0.009)))

    # 嘴：小弧線。開心是下彎的 U（笑），答錯是上凸的 ∩。
    mouth_half = w * 0.048
    mouth_y = w * (0.605 if happy else 0.645)
    amp = w * (0.042 if happy else 0.030)
    steps = 16
    pts = []
    for i in range(steps + 1):
        t = 2 * i / steps - 1
        x = cx - mouth_half + mouth_half * 2 * i / steps
        y = mouth_y + (amp if happy else -amp) * (1 - t * t)
        pts.append((int(x), int(y)))
    pygame.draw.lines(surf, ink, False, pts, max(2, int(w * 0.014)))
    for a, b in (pts[0], pts[-1]):
        pygame.draw.circle(surf, ink, (a, b), max(1, int(w * 0.007)))
    return pygame.transform.smoothscale(surf, (size, size))

# (物品內部名稱, 題目 i18n 前綴, 正確桶)
QUESTIONS = [
    ("乾淨紙箱", "q1", "paper"),
    ("飲品膠樽", "q2", "plastic"),
    ("鋁罐", "q3", "metal"),
    ("用過的紙巾", "q4", "general"),
    ("飲品膠樽", "q5", "plastic"),
]
# 依物品類別給的思考提示（存 i18n key，顯示時才翻譯）
RULE_KEYS = {
    "paper": "aitip.paper",
    "plastic": "aitip.plastic",
    "metal": "aitip.metal",
    "general": "aitip.general",
}

LEVEL_ONE_TIPS = {
    "報紙": "aitip.lv1_newspaper",
    "乾淨紙箱": "aitip.lv1_box",
    "乾淨書本": "aitip.lv1_book",
    "飲品膠樽": "aitip.lv1_drink",
    "洗頭水樽": "aitip.lv1_shampoo",
}


def sync_language():
    """從瀏覽器讀取語言設定（同源 localStorage，由外層網頁寫入）。

    桌面版沒有 browser.window，會一直用預設的粵語，不會報錯。
    回傳 True 表示語言有變，呼叫端可據此刷新依賴語言的資料。
    """
    try:
        import platform as browser
        raw = browser.window.localStorage.getItem("edu_lang")
    except Exception:
        raw = None
    code = raw if raw in ("hk", "cn", "en") else "hk"
    if code != i18n.LANG:
        set_lang(code)
        refresh_bins()
        return True
    return False


class FinalGame(PictureGame):
    # 這個作品用 1280×720 的視窗，中間放一張 1000×660 的畫布再等比放大。
    DISPLAY_SIZE = (1280, 720)

    def __init__(self, folder=None):
        super().__init__()
        # 視窗在父類別已經按 DISPLAY_SIZE 建好，這裡直接沿用（瀏覽器不能重建 canvas）。
        self.window = pygame.display.get_surface()
        self.screen = pygame.Surface((WIDTH, HEIGHT))
        self.viewport = pygame.Rect(94, 0, 1091, 720)
        self.data = Data() if folder is None else Data(folder)
        self.unlocked = self.data.state["unlocked_level"]
        self.muted = self.data.state["settings"].get("muted", False)
        self.slow = self.data.state["settings"].get("teacher_slow", False)
        self.practice = False
        self.paused = False
        self.teacher_confirm = False
        self.notice = ""
        self.portraits = {}
        self.pause_rect = pygame.Rect(146, 25, 92, 44)
        self.gear = pygame.Rect(852, 584, 119, 50)
        self.quiz_entry = pygame.Rect(388, 506, 224, 50)
        self.options_extra = ["paper", "plastic", "metal", "general", "skip", "score"]
        self.quiz_buttons = {key: pygame.Rect(62+i*225, 361, 200, 112) for i,key in enumerate(BINS)}
        self.student_id = self.data.state["student_id"]
        self.report_page = 0
        self.last_wrong = None
        # 小測的分數先歸零：正常流程由 begin_quiz() 設定，但這樣即使在
        # 任何中途狀態誤入 quiz_result 畫面，也不會因為缺屬性而整個崩掉。
        self.q_index = 0
        self.q_score = 0

    def menu_rect(self, number):
        return pygame.Rect(84 + number % 3 * 280, 275 + number // 3 * 103, 272, 84)

    def earth(self, center, radius, happy=True):
        """圓框裡的地球：卡通線稿（取代原本的插畫貼圖）。"""
        key = (radius, happy)
        if key not in self.portraits:
            self.portraits[key] = earth_surface(radius * 2, happy)
        # 外圈用很淡的天藍（答錯時淡橙）做光暈，和圓內的深海藍拉開層次。
        pygame.draw.circle(self.screen, "#d9eef8" if happy else "#f8e8d6", center, radius+4)
        self.screen.blit(self.portraits[key], (center[0]-radius,center[1]-radius))
        if not happy:
            self.icon("cross",(center[0]+radius-3,center[1]+radius-3),22)

    def start(self, level, practice=None):
        if practice is not None:
            self.practice = practice
        super().start(3 if level == 4 else level)
        self.level = level
        self.paused = False
        self.last_wrong = None
        self.elapsed = 0
        if level in (3, 4):
            self.message = ""
            self.machine_setup(level)

    def machine_setup(self, level):
        """把第三、四關的分類機歸零，回到「觀察」階段。"""
        rules, case = MACHINE_CASES[level]
        self.rules = dict(rules)
        self.mcase = list(case)
        self.flow = "watch"        # watch → find → fix → rerun →（全部正確）過關
        self.demo_t = 0.0          # 這一輪演示已經跑了多少秒
        self.demo_played = 0       # 已經播完幾件（用來觸發音效，不重播）
        self.marks = {}            # 物品索引 → True / False，本輪演示的結果
        self.focus = None          # 正在修的那一件
        self.fixed_count = 0       # 已修好幾條規則
        self.message = T("flow.watching")

    def finish(self, won):
        self.outcome = "win" if won else "retry"
        self.dragging = False
        if won:
            self.play("win")
            if not self.practice:
                self.unlocked = min(4,max(self.unlocked,self.level+1))
                state = self.data.state
                state["unlocked_level"] = self.unlocked
                key = str(self.level)
                state["best_scores"][key] = max(self.score,state["best_scores"].get(key,0))
                self.data.save()

    def advance_item(self):
        self.last_wrong = None
        super().advance_item()

    def drop_item(self):
        target = next((key for key, area in self.bins.items() if area.collidepoint(self.item.center)),None)
        name = self.sequence[self.item_index]
        self.last_wrong = ITEMS[name] if target is not None and target != ITEMS[name] else None
        super().drop_item()
        if self.last_wrong and not self.outcome:
            self.message = T("msg.closish")

    def update(self, seconds):
        if self.view == "play" and self.paused:
            return
        if self.view == "play" and not self.outcome:
            self.elapsed += seconds
        if self.view == "play" and not self.outcome and self.level in (3, 4):
            self.debug_update(seconds)
        if self.view != "play" or self.level != 4:
            super().update(seconds * (0.55 if self.practice and self.slow else 1))
        if self.view == "play" and self.level == 0 and self.outcome == "win" and not self.practice:
            self.win_delay = getattr(self,"win_delay",0) + seconds
            if self.win_delay >= 4:
                self.win_delay = 0
                self.start(1)
        else:
            self.win_delay = 0

    # ---------- 分類機流程（第三、四關共用） ----------
    # 舊版是「卡片直接印出舊規則 → 學生照抄 → 再點一次同一個桶驗證」，
    # 考的是閱讀提示而不是除錯。新版改成四步：
    #   watch（看分類機把每件垃圾送去哪）→ find（指認哪件錯了）
    #   → fix（改那條規則）→ rerun（再跑一次，看有沒有修好）
    # 只有「規則」是資料，畫面與判定都從規則即時算出來，所以改一條會立刻反映到每件物品。
    def demo_period(self):
        """每件物品在演示裡停留幾秒。重跑時快一點，免得每輪都要乾等。"""
        return 0.42 if self.flow == "rerun" else 0.66

    def demo_progress(self):
        """回傳 (已落定的件數, 正在下落那件的進度 0~1)。"""
        per = self.demo_period()
        if self.demo_t >= per * len(self.mcase):
            return len(self.mcase), 0.0
        done = int(self.demo_t / per)
        return done, (self.demo_t - done * per) / per

    def rule_output(self, index):
        """分類機把第 index 件物品送去哪個桶（就是查一次規則表）。"""
        return self.rules[ITEMS[self.mcase[index]]]

    def debug_update(self, seconds):
        if self.flow not in ("watch", "rerun"):
            return
        per = self.demo_period()
        self.demo_t += seconds
        done = min(int(self.demo_t / per), len(self.mcase))
        # 每落定一件就即時記下對錯並播一聲，讓紅叉既看得到也聽得到。
        while self.demo_played < done:
            index = self.demo_played
            self.demo_played += 1
            ok = self.rule_output(index) == ITEMS[self.mcase[index]]
            self.marks[index] = ok
            self.play("right" if ok else "wrong")
        if self.demo_t >= per * len(self.mcase) + (0.5 if self.flow == "watch" else 0.7):
            self.end_demo()

    def end_demo(self):
        # 重新由規則表算一次，不依賴剛才逐件補上的 marks，避免計時跳格時漏判。
        self.marks = {i: self.rule_output(i) == ITEMS[name]
                      for i, name in enumerate(self.mcase)}
        self.demo_t = 0.0
        if all(self.marks.values()):
            self.flow = "done"
            self.message = ""      # 結算框已有同樣的話，這裡再寫一次會重複
            self.score += 20
            self.finish(True)
            return
        self.flow = "find"
        self.focus = None
        self.message = T("flow.find")

    def case_rects(self):
        """傳送帶上三／四張物品卡的點擊區。"""
        count = len(self.mcase)
        width = 176 if count >= 4 else 200
        gap = (WIDTH - count * width) / (count + 1)
        return [pygame.Rect(int(gap + i * (width + gap)), 302, width, 80)
                for i in range(count)]

    def flow_hint(self):
        """目前階段的預設提示語。切換語言時用它換掉還留在畫面上的舊句子。"""
        if self.flow == "fix" and self.focus is not None:
            return T("flow.now_fix", item=item_name(self.mcase[self.focus]))
        if self.flow == "watch":
            return T("flow.watching")
        if self.flow == "rerun":
            return T("flow.running")
        return T("flow.find")

    def machine_click(self, pos):
        if self.outcome:
            return
        if self.flow == "find":
            for index, area in enumerate(self.case_rects()):
                if area.collidepoint(pos):
                    self.pick_case(index)
                    return
        elif self.flow == "fix":
            for key, area in self.bins.items():
                if area.collidepoint(pos):
                    self.try_fix(key)
                    return

    def pick_case(self, index):
        """學生指認「哪一件被送錯了」。"""
        if self.marks.get(index):
            # 指到本來就對的那件：不告訴他答案，只提示換一件看。
            self.feedback(False)
            self.message = T("flow.this_ok")
            self.penalty()
            return
        self.focus = index
        self.flow = "fix"
        self.score += 10
        self.feedback(True)
        self.message = T("flow.now_fix", item=item_name(self.mcase[index]))

    def try_fix(self, key):
        """學生點一個桶，代表「把這條規則改成送去這個桶」。"""
        name = self.mcase[self.focus]
        category = ITEMS[name]
        if key != category:
            self.feedback(False)
            self.message = T("flow.fix_bad", item=item_name(name), bin=bin_name(key))
            self.penalty()
            return
        self.rules[category] = key
        self.fixed_count += 1
        self.score += 10
        self.feedback(True)
        self.message = T("flow.fixed")
        self.flow = "rerun"
        self.demo_t = 0.0
        self.demo_played = 0
        self.marks = {}

    def penalty(self):
        """第 3 關只給提示、不扣血，讓學生敢試；第 4 關才扣 1 點生命值。"""
        if self.level != 4:
            return
        self.hp = max(0, self.hp - 1)
        if self.hp == 0:
            self.finish(False)

    def handle(self, event):
        old_muted = self.muted
        if hasattr(event,"pos"):
            x,y = event.pos
            event = pygame.event.Event(event.type, {**event.dict,
                     "pos": ((x-self.viewport.x)*WIDTH//self.viewport.w, y*HEIGHT//self.viewport.h)})
        self.dispatch(event)
        if self.muted != old_muted:
            self.data.state["settings"]["muted"] = self.muted
            self.data.save()

    def dispatch(self,event):
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_p and self.view == "play" and not self.outcome:
                self.paused = not self.paused
                self.dragging = False
                self.block = None
                if self.level < 3:
                    self.item.topleft = (int(self.item_x),283)
                return
            if self.view == "quiz_id":
                if event.key == pygame.K_BACKSPACE:
                    self.student_id = self.student_id[:-1]
                elif event.key == pygame.K_RETURN:
                    self.begin_quiz()
                elif len(self.student_id)<20 and re.fullmatch(r"[A-Za-z0-9_-]",event.unicode):
                    self.student_id += event.unicode
                if event.key != pygame.K_ESCAPE:
                    return

        if self.view == "play" and self.paused and event.type in (
            pygame.MOUSEBUTTONDOWN,pygame.MOUSEBUTTONUP,pygame.MOUSEMOTION
        ):
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if self.pause_rect.collidepoint(event.pos):
                    self.paused = False
                elif self.back.collidepoint(event.pos):
                    self.view = "teacher" if self.practice else "menu"
                elif self.mute.collidepoint(event.pos):
                    self.muted = not self.muted
            return

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            pos = event.pos
            if self.view == "menu":
                self.practice = False
                for level in range(self.unlocked + 1):
                    if self.menu_rect(level).collidepoint(pos):
                        self.start(level)
                        return
                if self.quiz_entry.collidepoint(pos):
                    self.view = "quiz_id"
                    self.notice = ""
                    return
                if self.gear.collidepoint(pos):
                    self.gear_start = pygame.time.get_ticks()
                    return
            if self.view == "play":
                if self.pause_rect.collidepoint(pos) and not self.outcome:
                    self.paused = True
                    self.dragging = False
                    self.block = None
                    if self.level < 3:
                        self.item.topleft = (int(self.item_x),283)
                    return
                if self.practice and (self.back.collidepoint(pos) or
                                      self.outcome and self.next.collidepoint(pos)):
                    self.view = "teacher"
                    return
                if self.outcome == "win" and self.level in (3,4) and self.next.collidepoint(pos):
                    if self.level == 3:
                        self.start(4)
                    else:
                        self.view = "reflection"
                        self.reflect_done.clear()
                    return
                if self.level in (3, 4) and not self.outcome:
                    if self.back.collidepoint(pos):
                        self.view = "teacher" if self.practice else "menu"
                    elif self.mute.collidepoint(pos):
                        self.muted = not self.muted
                    else:
                        self.machine_click(pos)
                    return
            if self.view in ("teacher","report","quiz_id","quiz","quiz_result"):
                self.special_click(pos)
                return
        if event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            pos = event.pos
            if self.view == "menu" and hasattr(self,"gear_start"):
                if self.gear.collidepoint(pos) and pygame.time.get_ticks()-self.gear_start >= 2000:
                    self.view = "teacher"
                    self.notice = ""
                del self.gear_start
                return
        super().handle(event)

    def guest_id(self):
        """給一個沒用過的訪客編號，讓沒鍵盤的裝置也能記錄成績。"""
        used = {row["student_id"] for row in self.data.rows()}
        n = 1
        while f"GUEST{n:02d}" in used:
            n += 1
        return f"GUEST{n:02d}"

    def begin_quiz(self):
        # 手機、平板沒有實體鍵盤，學生根本打不到字；canvas 又不會彈出
        # 虛擬鍵盤，所以「必須輸入學號」等於直接卡死這一頁。
        # 沒填就自動配一個訪客編號，成績照樣記錄、報告照樣匯出。
        if not self.student_id.strip():
            self.student_id = self.guest_id()
        if not re.fullmatch(r"[A-Za-z0-9_-]{1,20}", self.student_id):
            self.notice = T("quiz.need_id")
            return
        self.q_index = self.q_score = 0
        self.q_choice = None
        self.view = "quiz"

    def special_click(self,pos):
        if self.mute.collidepoint(pos):
            self.muted = not self.muted
        elif self.back.collidepoint(pos):
            self.view = "teacher" if self.view == "report" else "menu"
            self.notice = ""
            self.teacher_confirm = False
        elif self.view == "teacher":
            for level in range(5):
                if self.menu_rect(level).collidepoint(pos):
                    self.start(level,practice=True)
                    return
            if pygame.Rect(84,503,232,52).collidepoint(pos):
                self.slow = not self.slow
                self.data.state["settings"]["teacher_slow"] = self.slow
                self.data.save()
            elif pygame.Rect(383,503,232,52).collidepoint(pos):
                self.view = "report"
                self.report_page = 0
                self.notice = ""
            elif pygame.Rect(682,503,232,52).collidepoint(pos):
                if self.teacher_confirm:
                    self.unlocked = 0
                    self.data.state["unlocked_level"] = 0
                    self.data.state["best_scores"] = {}
                    self.data.save()
                    self.teacher_confirm = False
                    self.notice = T("teacher.reset_done")
                else:
                    self.teacher_confirm = True
                    self.notice = T("teacher.reset_confirm")
        elif self.view == "report":
            rows = self.data.rows()
            if pygame.Rect(88,546,146,50).collidepoint(pos):
                self.report_page = max(0,self.report_page-1)
            elif pygame.Rect(249,546,146,50).collidepoint(pos):
                self.report_page = min(max(0,(len(rows)-1)//8),self.report_page+1)
            elif pygame.Rect(664,546,248,50).collidepoint(pos):
                self.notice = T("teacher.exported", name=self.data.export().name)
        elif self.view == "quiz_id" and self.go.collidepoint(pos):
            self.begin_quiz()
        elif self.view == "quiz":
            if self.q_choice is not None:
                if self.go.collidepoint(pos):
                    self.q_index += 1
                    self.q_choice = None
                    if self.q_index == len(QUESTIONS):
                        self.data.record(self.student_id,self.q_score)
                        self.view = "quiz_result"
            else:
                for key,area in self.quiz_buttons.items():
                    if area.collidepoint(pos):
                        self.q_choice = key
                        right = key == QUESTIONS[self.q_index][2]
                        self.q_score += 20 if right else 0
                        self.play("right" if right else "wrong")
                        break
        elif self.view == "quiz_result" and self.go.collidepoint(pos):
            self.view = "menu"

    def draw_menu(self):
        self.earth((500,113),80)
        self.text(T("menu.title"),500,213,44,center=True)
        self.text(T("menu.sub_stem"),500,250,19,center=True)
        self.draw_level_cards(False)
        self.button(self.quiz_entry,T("menu.quiz"))
        self.button(self.gear,T("menu.teacher"))
        self.text(T("menu.teacher_long"),911,647,19,center=True)
        self.text(T("menu.pick_level"),500,597,22,center=True)

    def draw_level_cards(self,teacher):
        keys = ("plastic","paper","metal","bulb","robot")
        for level,key in enumerate(keys):
            area = self.menu_rect(level)
            locked = not teacher and level>self.unlocked
            self.rect(area.move(0,4),"#bfd9c9")
            self.rect(area,"#f0f3eb" if locked else WHITE)
            self.icon(key,(area.x+43,area.centery),52)
            name = T("lv.menu.2") if level == 2 else T(f"lv.card.{level}") if level in (3,4) else T(f"lv.{level}")
            self.text(f"{level}　{name}",area.x+82,area.y+13,22)
            best = self.data.state["best_scores"].get(str(level))
            if locked:
                sub = T("menu.locked")
            elif teacher:
                sub = T("menu.try")
            elif best is not None:
                sub = T("menu.best", n=best)
            else:
                sub = T("menu.start")
            self.text(sub,area.x+84,area.y+47,19)

    def draw_header(self):
        super().draw_header()
        if self.level == 4:
            # 基礎畫面只識別 0 至 3；最終關由 draw_play 繪製標題。
            return
        self.draw_controls()

    def draw_controls(self):
        # 只在第 0 關畫教程提示；第 3、4 關這塊白色會蓋掉生命值愛心，
        # 而第 4 關答錯要扣血，愛心必須看得見。
        if self.level == 0:
            self.rect((112,96,193,55),WHITE,0)
            self.text(T("hud.try_with_me"),125,110,22)
        if not self.outcome:
            self.button(self.pause_rect,T("btn.resume") if self.paused else T("btn.pause"))
        if self.practice:
            self.text(T("hud.practice"),264,37,19)

    def draw_machine(self):
        """第三、四關的主畫面：傳送帶上的物品卡 + 下方四個桶 + 落點標記。"""
        self.text(self.message, 500, 190, 22, center=True)
        if self.flow in ("find", "fix"):
            total = 1 if self.level == 3 else 2
            self.text(T("flow.progress", c=self.fixed_count, n=total), 500, 218, 19, center=True)

        # 修規則時把出錯的那條規則亮出來（第 4 關有兩條，只顯示正在處理的那條）。
        if self.flow == "fix" and self.focus is not None:
            name = self.mcase[self.focus]
            self.rect((176, 236, 648, 46), "#ffe9c9", 12)
            self.text(T("flow.rule_of", item=item_name(name),
                        bin=bin_name(self.rule_output(self.focus))),
                      500, 259, 19, center=True)

        # 傳送帶（紋理慢慢滾動，表示機器一直在跑）
        self.rect((0, 296, WIDTH, 94), "#3d5d58", 0)
        offset = int(pygame.time.get_ticks() / 45) % 58
        for x in range(-58 + offset, WIDTH, 58):
            pygame.draw.line(self.screen, "#69847d", (x, 306), (x, 380), 3)

        done, frac = self.demo_progress()
        for index, area in enumerate(self.case_rects()):
            self.draw_case_card(index, area, falling=(index == done))
        if done < len(self.mcase) and self.flow in ("watch", "rerun"):
            self.draw_falling(done, frac)

        self.draw_bins()
        self.draw_link()
        self.draw_marks()

    def draw_link(self):
        """修規則時，用虛線把「正在處理的那一件」連到「分類機送它去的桶」。

        這條虛線是這一關最重要的視覺說明：學生要親眼看到「規則」與「結果」
        是同一件事的兩面，而不是兩個分開的填空題。
        """
        if self.flow != "fix" or self.focus is None:
            return
        area = self.bins.get(self.rule_output(self.focus))
        if area is None:
            return
        card = self.case_rects()[self.focus]
        start = (card.centerx, card.bottom)
        end = (area.centerx, area.top - 6)   # 畫到桶頂，標記會壓在線上，看起來像「這條線通到這個桶」
        steps = 28
        for i in range(0, steps, 2):
            x1 = start[0] + (end[0] - start[0]) * i / steps
            y1 = start[1] + (end[1] - start[1]) * i / steps
            x2 = start[0] + (end[0] - start[0]) * (i + 1) / steps
            y2 = start[1] + (end[1] - start[1]) * (i + 1) / steps
            pygame.draw.line(self.screen, "#b8862f", (x1, y1), (x2, y2), 3)

    def draw_case_card(self, index, area, falling=False):
        name = self.mcase[index]
        ok = self.marks.get(index)
        if ok is True:
            self.rect(area, "#e6f5ea")
        elif ok is False:
            self.rect(area, "#fdeceb")
        else:
            self.rect(area, WHITE)
        if self.flow == "fix" and self.focus == index:
            # 正在處理的那件閃金色邊框，學生一眼知道現在改的是哪一件。
            edge = "#e0a63a" if pygame.time.get_ticks() // 320 % 2 else "#f3cd8a"
        elif ok is True:
            edge = "#4f9d78"
        elif ok is False:
            edge = "#d06a5f"
        else:
            edge = "#9dbfae"
        self.rect(area, edge, width=3)
        if not falling:
            self.item_icon(name, (area.centerx, area.y + 29), 42)
        self.text(item_name(name), area.centerx, area.y + 62,
                  18 if i18n.LANG == "en" else 19, center=True)
        if ok is not None:
            self.icon("check" if ok else "cross", (area.right - 17, area.y + 16), 26)

    def draw_falling(self, index, frac):
        """正在落桶的那一件：由卡片位置飛向它被送去的桶，越飛越小。"""
        name = self.mcase[index]
        area = self.bins.get(self.rule_output(index))
        if area is None:
            return
        start = self.case_rects()[index].center
        ease = frac * frac * (3 - 2 * frac)          # smoothstep，起步與停下都柔和
        x = int(start[0] + (area.centerx - start[0]) * ease)
        y = int(start[1] + (area.top - start[1]) * ease)
        self.item_icon(name, (x, y), int(42 - 10 * ease))

    def draw_marks(self):
        """桶頂顯示落點對錯；同一個桶有幾件就橫向分開，不會疊在一起。"""
        buckets = {}
        for index in self.marks:
            buckets.setdefault(self.rule_output(index), []).append(self.marks[index])
        for key, results in buckets.items():
            area = self.bins.get(key)
            if area is None:
                continue
            span = 32
            left = area.centerx - (len(results) - 1) * span // 2
            for i, ok in enumerate(results):
                self.icon("check" if ok else "cross", (left + i * span, 466), 28)

    def draw_ai_tip(self, y):
        self.rect((151,y+4,698,68),"#b9d6c7",15)
        self.rect((151,y,698,68),CREAM,15)
        self.icon("robot",(199,y+34),44)
        self.text(T("aitip.title"),241,y+8,19)
        tip_key = RULE_KEYS[self.last_wrong]
        if self.level == 1:
            name = self.sequence[self.item_index]
            tip_key = LEVEL_ONE_TIPS.get(name, tip_key)
        self.text(T(tip_key),241,y+34,22)

    def logical_mouse(self):
        x,y = pygame.mouse.get_pos()
        return (x-self.viewport.x)*WIDTH//self.viewport.w,y*HEIGHT//self.viewport.h

    def draw_special(self):
        self.button(self.back,T("btn.back_special"))
        title_keys = {"teacher":"menu.teacher","report":"quiz.report_title","quiz_id":"quiz.title",
                      "quiz":"quiz.title","quiz_result":"quiz.done_title"}
        # 用 get 兜底：日後若新增畫面而忘了登記標題，也不會整個畫面炸掉。
        self.text(T(title_keys.get(self.view, "quiz.title")),500,84,44,center=True)
        if self.view == "teacher":
            self.text(T("teacher.sub"),500,170,22,center=True)
            self.draw_level_cards(True)
            slow_label = T("teacher.slow_on") if self.slow else T("teacher.slow_off")
            for x,label in ((84,slow_label),(383,T("teacher.report")),(682,T("teacher.reset"))):
                self.button(pygame.Rect(x,503,232,52),label)
            self.text(self.notice,500,598,22,center=True)
        elif self.view == "report":
            self.text(T("report.head"),500,154,22,center=True)
            rows = self.data.rows()
            for i,row in enumerate(rows[self.report_page*8:self.report_page*8+8]):
                y = 189+i*41
                self.rect((123,y,754,36),WHITE,6)
                for x,key in ((233,"student_id"),(500,"attempts"),(757,"best_score")):
                    self.text(str(row[key]),x,y+18,19,center=True)
            if not rows:
                self.text(T("report.empty"),500,265,22,center=True)
            for x,w,label in ((88,146,T("report.prev")),(249,146,T("report.next")),
                              (664,248,T("report.export"))):
                self.button(pygame.Rect(x,546,w,50),label)
            self.text(self.notice or str(self.data.folder),500,621,19,center=True)
        elif self.view == "quiz_id":
            self.earth((500,218),70)
            self.text(T("quiz.input_id"),500,338,26,center=True)
            self.rect((310,389,380,61),WHITE)
            # 光標用 ASCII 直線：字體子集裡有「|」，但沒有「│」，
            # 用製表符會變成方框，看起來像壞掉。
            self.text(self.student_id+"|",500,420,26,center=True)
            self.text(self.notice or T("quiz.info"),500,490,22,center=True)
            # 學號空白時按鈕直接寫「直接開始（訪客）」，
            # 手機用戶不會因為打不到字而卡在這頁。
            self.button(self.go, T("quiz.start") if self.student_id.strip()
                        else T("quiz.start_guest"))
        elif self.view == "quiz":
            name, prefix, expected = QUESTIONS[self.q_index]
            self.text(f"{self.q_index+1}／5",500,135,22,center=True)
            self.text(T(f"{prefix}.q"),500,187,26,center=True)
            self.item_icon(name,(500,270),105)
            for key,area in self.quiz_buttons.items():
                self.bin_art(key,area)
                if self.q_choice is not None and (key==expected or key==self.q_choice):
                    self.icon("check" if key==expected else "cross",(area.right-15,area.y+14),32)
            if self.q_choice is not None:
                self.text(T(f"{prefix}.e"),500,518,22,center=True)
                self.button(self.go,T("quiz.see_result") if self.q_index==4 else T("quiz.next_q"))
        else:
            self.earth((500,252),100)
            self.text(f"{self.q_score}／100",500,409,44,center=True)
            self.text(T("quiz.recorded"),500,491,22,center=True)
            self.button(self.go,T("btn.back_levels"))

    def on_language_changed(self):
        """外層網頁切換語言後，把還在畫面上一句舊語言的提示換成新語言。

        已經顯示過的長訊息無法反向翻譯，所以在遊戲中一律換成該關的起始提示；
        選單、小測等畫面的文字是每次重繪時才查表，本來就會自動更新。
        """
        pygame.display.set_caption(T("menu.title"))
        self.notice = ""
        if self.view == "play" and not self.outcome:
            if self.level in (3, 4):
                self.message = self.flow_hint()
            elif self.level == 0:
                self.message = T("msg.lv0_intro")
            else:
                self.message = T("msg.drag_how")

    def draw_play(self):
        if self.level in (3, 4):
            level = self.level
            # 沿用關卡狀態列，下方留給單題卡片。
            message = self.message
            self.level = 3
            self.message = ""
            PictureGame.draw_header(self)
            self.level = level
            self.message = message
            self.rect((241,23,490,49),"#e7f4e7",0)
            self.text(T("menu.level", n=level, title=T(f"lv.{level}")),500,45,32,center=True)
            self.draw_controls()
            self.draw_machine()
        else:
            self.draw_header()
            self.draw_sort()
        if self.last_wrong and not self.outcome:
            self.draw_ai_tip(397)
        if self.outcome:
            self.draw_result()
            if self.outcome=="retry":
                self.rect((230,227,540,64),WHITE)
                self.text(T("result.lose2"),500,257,32,center=True)
            elif self.level in (3,4):
                self.rect((230,227,540,64),WHITE)
                self.text(T("result.first_fixed") if self.level==3 else T("result.last_win"),500,257,32,center=True)
                if self.level==4:
                    # 地球與彩屑都放在白框（y=202 起）之上，避免壓住結算文字
                    self.earth((500,150),40)
                    for i in range(8):
                        t = pygame.time.get_ticks()//24 + i*21
                        pygame.draw.circle(self.screen,("#dd985a","#6dbb9a","#8d76c2")[i%3],
                                           (301+i*57,104+(t%80)),4)
                if self.practice:
                    next_label = T("result.back_teacher")
                elif self.level == 3:
                    next_label = T("btn.next")
                else:
                    next_label = T("result.next_reflect")
                self.button(self.next,next_label)
            if self.practice and self.level not in (3,4):
                self.button(self.next,T("result.back_teacher"))
            if self.outcome == "retry" and self.last_wrong:
                self.draw_ai_tip(478)
        if self.paused:
            self.rect((260,270,480,128),WHITE)
            self.text(T("pause.title"),500,309,32,center=True)
            self.text(T("pause.hint"),500,360,22,center=True)

    def draw(self):
        self.screen.fill("#e7f4e7")
        pygame.draw.ellipse(self.screen,"#d4ead9",(-260,555,1150,220))
        pygame.draw.ellipse(self.screen,"#d0e9d9",(540,560,800,190))
        if self.view == "menu":
            self.draw_menu()
        elif self.view == "reflection":
            self.draw_reflection()
        elif self.view == "play":
            self.draw_play()
        else:
            self.draw_special()
        self.button(self.mute,T("btn.mute_short") if self.muted else T("btn.mute"))
        self.window.fill("#163b3b")
        self.window.blit(pygame.transform.smoothscale(self.screen,self.viewport.size),self.viewport)
        pygame.display.flip()


def _report_crash(text):
    """在瀏覽器裡把錯誤訊息印出來，方便老師回報問題（桌面版只印到終端）。"""
    print(text)
    try:
        import platform as browser
        document = browser.window.document
        document.title = "載入失敗：" + text.splitlines()[-1][:80]
        box = document.createElement("pre")
        box.textContent = text
        box.style.cssText = ("position:fixed;inset:8px;z-index:9999;overflow:auto;"
                             "background:#fff;color:#b3261e;font-size:12px;"
                             "padding:12px;border-radius:8px;white-space:pre-wrap;")
        document.body.appendChild(box)
    except Exception:
        pass


async def main():
    """主迴圈。每畫一格就 await 一次，瀏覽器才有機會處理滑鼠與鍵盤事件。

    注意：這裡刻意不用 clock.tick(60)。在 WebAssembly 內 SDL_Delay 會卡住
    整個執行緒，畫面就永遠不會更新；改為自己用毫秒時鐘計算每格間隔。
    """
    game = FinalGame()
    last = pygame.time.get_ticks()
    frames = 0
    try:
        while game.running:
            now = pygame.time.get_ticks()
            seconds = min((now - last) / 1000, 0.05)
            last = now
            for event in pygame.event.get():
                game.handle(event)
            if game.running:
                game.update(seconds)
                game.draw()
            # 每 20 幀問一次外層網頁的語言設定（同源 localStorage）。
            # 不做每幀讀取，避免無謂的 JS 呼叫拖慢畫面。
            frames += 1
            if frames % 20 == 0 and sync_language():
                game.on_language_changed()
            await asyncio.sleep(0)
    finally:
        pygame.quit()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except Exception:
        import traceback
        _report_crash(traceback.format_exc())
        raise
